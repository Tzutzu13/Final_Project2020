classdef parameters_usv
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties % flags- for stages
        % all the values are the default value
        preprocessing   = false;
        segmantation    = true;
        Features        = false;
        classification  = false;
        roc             = false;
        save_feautre    = true;
        save_signal     = false;
        save_class      = true;
        plot_flag       = true;
        trial           = 1;
        mode            = 1; % 1 = triainig, 2= analysis
    end
    properties % Thresholds
        % all the values are the default value
        TH1 =   1800;
        TH2 =   2400;
        p1  =   12;
        p2  =   14;
        Freq_Limits = [32000,125000];
        Freq_var_rate = 3000 ;%the Variation limits for formants in following frames
        Dtw_threshold = 0;
        
    end
    properties % files path
        % all the path to the files
        signal_path         = '';
        channel             = [];
        date                = [];
        results_folder      = ''; % for each signal
        gold_standart_xls   = '';
        ROC_mat_file        = '';
        calls_feautre_mat   = '';
        model_path          = [];
    end
    properties  % real data
        signal              = [];
        model_feature       = [];
        StEndMatF           = [];
        Class_vec           = [];
        Num_calls           = 0;
        
    end
    properties % properties for feature extraction
        % all the path to the files
        Pup_num = [];
        Session_num = [];
        Sheet_num = [];
    end
    properties % all options
        
        plot_list ={'raster plot',''};
        catagories_list ={'',''};
        
        
    end
    methods
        function [obj] = getall_wavfiles(obj,Dir)
            All_sub_dir_string = genpath(Dir);
            % separate string to cells
            I = strfind(All_sub_dir_string,';');
            All_sub_dir = cell(1,length(I));
            files = All_sub_dir;
            I = [0,I];
            for ii=1:length(I)-1
                All_sub_dir{ii}= All_sub_dir_string(I(ii)+1:I(ii+1)-1);
                files{ii} = dir(fullfile(All_sub_dir{ii},'*.wav'));
                for jj=1:length(files{ii})
                    last_cell=numel(obj.signal_path);
                    obj.signal_path{1,last_cell+1} = fullfile(All_sub_dir{ii},files{1,ii}(jj,1).name);
                end
            end
        end % end of function getall_wavfiles
        function [obj] = built_result_subdir(obj)
            % Input check
            %-------------
            if isempty(obj.results_folder) || isempty(obj.signal_path)
                disp('No result folder/ signals!, please enter the missing data ');
                return;
            end
            
            NumOfSignals = numel(obj.signal_path);
%             if obj.create_models
%                 mkdir(fullfile(obj.results_folder,'models'));
%             end
            for ii=1:NumOfSignals
                [~,pure_name,~] = fileparts(obj.signal_path{ii}) ;
                
                mkdir(fullfile(obj.results_folder,pure_name));
                
            end
        end % end of function -built_result_subdir
        function [obj] = mode_adaptor(obj,mode)
            switch mode
                case 1 %training
                    %I. set mode
                    obj.made = 1;
                    %II. enable/disable fields
                    
                    %III.catagory
                    
                    %IX. plot options
                    
                case 2 %analysis
                    %I. set mode
                    obj.made = 2;
                    %II. enable/disable fields
                    
                    %III.catagory
                    
                    %IX. plot options
            end
        end
        function [obj]=load_feature_from_path(obj,path_list,field,varargin)
            % I.INPUT CHECK - method 'a' - append\ over write
            if nargin==4 && strcmpi(varargin{1},'a')
                IDX = numel(getfield(obj,field))+1; % start upload from the first empty cell
            else
                IDX = 1; % over write
                obj.model_feature = struct('name','','index',[],'features',[]);
            end
            
            if ischar(path_list)
                path_list  = {path_list}; % insert to a cell
            end
            %=====================================
            % LOOP ON LIST
            for ii = 1:numel(path_list)
                tmp_name=whos('-file',path_list{ii});
                
                tmp =load(path_list{ii},tmp_name.name);
                obj =  setfield(obj,{1},field,{IDX+ii-1},getfield(tmp,tmp_name.name));
                clear tmp tmp_name;
            end
        end % end of load feature
    end
    
end

