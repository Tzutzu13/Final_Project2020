function [param, err_flag ] = skeleton_usv( param )
%INPUT
%-----
% param is a class that - all his properties can be gathered from a
% designed GUI.
% OUTPUT
%-------
% err_flag
% in case there was an error
%===========================================
%% STEP I   - create output dir, and open a log file
%===========================================
err_flag = 1;
dbstop if error

if ~isdir(param.results_folder)
    mkdir(param.results_folder)
end
%===========================================
%% Check which kind of subjects we have:
global choice;
global EER
choice = 2;
%% STEP X. - ROC
%==========================================
if param.roc
%     [Pd, Pf, TotNd, TotNm, TotNf] = create_ROC( param, 1 );

     [Pf,Pd,EER,ind,TNR,PPV,NPV,Acc  ] = error_check( param );
        %
        %[Pf,Pd,EER,ind,TNR ] = errCheckForOldRecs( param )
        %
    figure;plot([0 Pf(1:end-1) 1],[0 Pd(1:end-1) 1],'-o','Linewidth',1);
    
    
    hold on;
 x = [Pf(end) 1];
y = [Pd(end-1) Pd(end)];
line(x,y,'LineWidth',1);
%     plot(line([0 0],[1 1]));
    xlim([0 1]);
    ylim([0 1]);
%     grid on;
    xlabel('False Positive Rate'); ylabel('True Positive Rate');
    AUC = trapz([0 Pf 1],[0 Pd 1]);
    title('ROC curve');
    hold on;
    plot(Pf(ind),Pd(ind),'r*','Linewidth',1.5); gtext(['AUC=' num2str(AUC)]);
end
%% STEP II   -  segmentation and preprocessing
%===========================================
% LOOP ON ALL SIGNALS
if param.segmantation
    for ii= 1: length(param.signal_path)-1
        
        [ param]    = Segmentation4Signal_2( param,ii );
        
    end     % end of loop
    param   = Segmentation4Signal_2( param,length(param.signal_path),'end' );
    %[ param ] = Real_time( param );
    if ~isempty(param)
      err_flag = 0;
    end
end %end of step II
%===========================================

%% preSTEP III
%===========================================
if (param.classification)%||param.roc) && ~param.segmantation
    log_name = fullfile(param.results_folder,['Trial_',num2str(param.trial),'_',date,'.txt']);
    
    % move all calls feature to result_folder
    for ii=1:numel(param.calls_feautre_mat)
        [~,pure_name,ext] = fileparts(param.calls_feautre_mat{ii});
        if ~strcmpi(param.calls_feautre_mat{ii},fullfile(param.results_folder,[pure_name,ext]))
            copyfile(param.calls_feautre_mat{ii},fullfile(param.results_folder,[pure_name,ext]));
            param.calls_feautre_mat{ii} = fullfile(param.results_folder,[pure_name,ext]);
        end
    end
    % and create LOG file
    if ~exist(log_name,'file')
        [ err_flag,param.signal_path] = dir2txtlog( param.calls_feautre_mat,log_name );
        if err_flag
            error('some error happend during txt log file creation');
        end
    end
        % loop on all feautre mat to load signal path
        for ii=1:numel(param.calls_feautre_mat)
            load(param.calls_feautre_mat{ii});
            try
                param.signal_path{ii,1} = original_signal_path;
                param.StEndMatF{ii,1} = StEndMatF;
                %if size(param.StEndMatF{ii,1},1)==2
                %    param.StEndMatF{ii,1}(:,3)=(-1);
                %end
            catch
                display('MAT File is not in the right format , check your input')
                return;
            end
            clear original_signal_path  StEndMatF
        end
end
%===========================================
%% STEP III. - creating models \ if  required
%===========================================
% if param.create_models

% end %end of step III
%===========================================
%% STEP IX. - classification \ if  required
%===========================================
if param.classification
    if isempty(param.model_feature)&& (~isempty(param.model_path))
        param =load_feature_from_path(param,param.model_path,'model_feature');
    end
    [ label_vec ] = DTW_classifier( bigData.data(:,bigData.headers.FORMANT_3D) , param.model_feature);
    if ~isempty(label_vec)        
        bigData.data(:,bigData.headers.LABEL) = mat2cell(label_vec(:),ones(length(label_vec),1),1);
        param  = datastruct2file( param,bigData );
        save(fullfile(param.results_folder,'Labeled_Data'),'bigData');
    end
end %end of step IX
%==========================================
%% STEP X. - ROC
%==========================================
% if param.roc
% %     [Pd, Pf, TotNd, TotNm, TotNf] = create_ROC( param, 1 );
%     [Pd_start,pf_start,Pd_end,pf_end,Pdtot, Pftot] = create_ROC( param, 1 );
%     Pattern = ['o','d','*','h','p','+','s'];
%     figure;
%         subplot(3,1,1);
%         [B,I] = sort(pf_start);
%         Pf = B;
%         Pd = Pd_start(I);
%         plot([0 Pf],[0 Pd],'Linewidth',1.5);
%         hold on;
%         for i = 1:length(Pattern)
%             plot(Pf(i),Pd(i),Pattern(i),'Linewidth',2);
%         end
%         hold off;
%         xlabel('Pf'); ylabel('Pd'); grid on;
%         title('Start Syllable points  - ROC curve');
%         xlim([0 1]);
%         ylim([0 1]);
%         subplot(3,1,2);
%         [B,I] = sort(pf_end);
%         Pf = B;
%         Pd = Pd_end(I);
%         plot([0 Pf],[0 Pd],'Linewidth',1.5);
%         hold on;
%         for i = 1:length(Pattern)
%             plot(Pf(i),Pd(i),Pattern(i),'Linewidth',2);
%         end
%         hold off;
%         xlabel('Pf'); ylabel('Pd'); grid on;
%         title('End Syllable points - ROC curve');
%          xlim([0 1]);
%         ylim([0 1]);
%         
%         subplot(3,1,3);
%         [B,I] = sort(Pftot);
%         Pf = B;
%         Pd = Pdtot(I);
%         plot(Pf,Pd,'Linewidth',1.5);
%         hold on;
%         for i = 1:length(Pattern)
%             plot(Pf(i),Pd(i),Pattern(i),'Linewidth',2);
%         end
%         hold off;
%         xlabel('Pf'); ylabel('Pd'); grid on;
%         title('Syllables Detection - ROC curve');
%         legend('ROC Curve','tr=5','tr=10','tr=15','tr=20','tr=25','tr=30','tr=50');
%          xlim([0 1]);
%         ylim([0 1]);
%         
% end
%==========================================
%% STEP XI - Temporal Features Extraction
%==========================================

% getTemporalFeatures(param, session, row)

%==========================================
%% STEP XII - Plot (interactive segmentation)
%==========================================
% if param.plot_flag     
%     outcome_per_signal(param)
% end

% %% Step XIII - Create bigData class for all combination of modes (except roc)
% %==========================================
% if choice == 2
%     str = 'C:\Users\Dror\Documents\MATLAB\codes\12_xls_tables\gold standard - pups_90.xlsx';
%     [ bigData ] = data_struct( param,2);
% else
%     str = 'C:\Users\Dror\Documents\MATLAB\codes\12_xls_tables\gold standard-Adults.xlsx';
% 	[ bigData ] = data_struct( param,1);
% end
%  if ~isempty(bigData)
%       err_flag = 0;
%  end
% for ii=1: numel(param.signal_path(:,1))
%     [~, name,~] =fileparts(param.signal_path{ii});
%     I=strcmpi(bigData.data(:,bigData.headers.NAME),name);
%     if any(I>0) && ~isempty(param.channel)
%         bigData.data(I,bigData.headers.CHANNEL)=param.channel(ii);
%         bigData.data(I,bigData.headers.DATE)=param.date(ii);        
%     end
% end
% save(fullfile(param.results_folder,'bigData'),'bigData');
% 
% if param.save_class
%     save(fullfile(param.results_folder,'param_class'),'param');
% end
% %end
%==========================================
end     % end of skeleton

