function [Signal1]=Preprocessing(Signal,Fs,varargin)
%INPUT:
%Signal - the given signal.
%Fs - Sampling Frequency.
%alpha - Pre-emphasis filters parameter.
%FrameLength - Frame length in seconds.
%Overlap - Overlapping in Percentage.

%OUTPUT:
%newSignal- The Signal after Preprocessing.
%1. DC removal.
%2. Pre-emphasis filter.
%3. framing.
%4. windowing.

 %2. Pre-emphasis filter.
%=======================
%alpha=0.99;
%PreEmphasisFilter=[1 -alpha];
%figure
%freqz(PreEmphasisFilter,1)

%Signal2=filter(PreEmphasisFilter,1,Signal1);
%Signal2=Signal1;
%option1
%========

%a=lpc(Signal,4);

%y=filter(a,1,Signal);

%wavwrite(y,Fs,[SignalName(1:end-4),'_LPC4']);
%y2 = filter(b,1,Signal);
%wavwrite(y2,Fs,[SignalName(1:end-4),'_LPC5']);
% d = fdesign.bandpass('N,F3dB1,F3dB2',10,22000,120000,Fs);
% Hd = design(d,'butter');
% 
% b= lpc(Signal,4);
% 
% % less intense filter
% Z = roots(b); 
% R = 0.5*abs(Z);
% 
% theta = angle(Z);
% Z = R.*exp(1i*theta);
% a = poly(Z);
% %Signal = filter(a,1,Signal);
% Signal = filter(Hd,Signal);

%1. DC REMOVAL
%==============
Signal= Signal-mean(Signal);
%h= 'after_filter.wav';
%if nargin>2
    % save new signal at
%audiowrite(Signal1,Fs,[varargin{1}(1:end-4),'_afterBP']);
%end
%wavwrite(Signal2,Fs,h)

%%%%%%% low pass filter cutoff 120kHz %%%%%%%%
d = fdesign.lowpass('Fp,Fst,Ap,Ast',100*10^3,120*10^3,0.5,40,250*10^3);
Hd = design(d,'equiripple');
Signal1 = filter(Hd,Signal);



end %EOF.
