function [c_Xout,c_added_info_out ]= spectrogram_disp(x,fs,c_Xin,c_added_info, Axes, param, IDX)

%MYSPECTROGRAM Calculate spectrogram from signal.
% B = MYSPECTROGRAM(A,NFFT,Fs,WINDOW,NOVERLAP) calculates the
%     spectrogram for the signal in vector A.
%
% NFFT is the FFT size used for each frame of A.  It should be a
% power of 2 for fastest computation of the spectrogram.
%
% Fs is the sampling frequency. Since all processing parameters are
% in units of samples, Fs does not effect the spectrogram itself,
% but it is used for axis scaling in the plot produced when
% MYSPECTROGRAM is called with no output argument (see below).
%
% WINDOW is the length M window function applied, IN ZERO-PHASE
% FORM, to each frame of A.  M cannot exceed NFFT.  For M<NFFT,
% NFFT-M zeros are inserted in the FFT buffer (for interpolated
% zero-phase processing).  The window should be supplied in CAUSAL
% FORM.
%
% NOVERLAP is the number of samples the sections of A overlap, if
% nonnegative.  If negative, -NOVERLAP is the "hop size", i.e., the
% number of samples to advance successive windows.  (The overlap is
% the window length minus the hop size.)  The hop size is called
% NHOP below.  NOVERLAP must be less than M.
%
% If doplot is nonzero, or if there is no output argument, the
% spectrogram is displayed.
%
% When the spectrogram is displayed, it is ``clipped'' dbdown dB
% below its maximum magnitude.  The default clipping level is 100
% dB down.
%
% Thus, MYSPECTROGRAM splits the signal into overlapping segments of
% length M, windows each segment with the length M WINDOW vector, in
% zero-phase form, and forms the columns of B with their zero-padded,
% length NFFT discrete Fourier transforms.
%
% With no output argument B, MYSPECTROGRAM plots the dB magnitude of
% the spectrogram in the current figure, using
% IMAGESC(T,F,20*log10(ABS(B))), AXIS XY, COLORMAP(JET) so the low
% frequency content of the first portion of the signal is displayed
% in the lower left corner of the axes.
%
% Each column of B contains an estimate of the short-term,
% time-localized frequency content of the signal A.  Time increases
% linearly across the columns of B, from left to right.  Frequency
% increases linearly down the rows, starting at 0.
%
% If A is a length NX complex signal, B is returned as a complex
% matrix with NFFT rows and
%      k = floor((NX-NOVERLAP)/(length(WINDOW)-NOVERLAP))
%        = floor((NX-NOVERLAP)/NHOP)
% columns.  When A is real, only the NFFT/2+1 rows are needed when
% NFFT even, and the first (NFFT+1)/2 rows are sufficient for
% inversion when NFFT is odd.
%
% See also: Matlab's SPECTROGRAM and Octave's STFT function.
% 02/04/02/jos: Created
% 02/12/04/jos: Added dbdown
% 07/23/08/jos: Changed name from SPECTROGRAM to MYSPECTROGRAM
% list of varargin
% c_Xin, nargin==8, is c_Xin data of the previous spectogram, for a
% faster operator
% varargin{1}, nargin==9 , stareEnd table , 3rd column is for
% classification
% varargin{2}, nargin==10, name of labels of the classification
% varargin{3}, nargin==11, time formants
% varargin{4}, nargin==12, frequencies value match the time in varargin{4}
%added_info = struct('StEndMatF',[],'cmap_types',[],'catagory',[],'Time',[],'Formants',[],'dbdown',[]);
%Xin =struct('t',[],'f',[],'X',[]);

%INPUT CHECK
%============

% assert(isa(x,'double') && isreal(x));
% assert(isa(fs,'double'));
% assert(isa(c_Xin,'struct'));
% assert(isa(c_Xin.t,'double'));
% assert(isa(c_Xin.f,'double'));
% assert(isa(c_Xin.X,'double'));
%coder.cstructname(c_added_info,'added_info4dispType');
%assert(isa(c_added_info,'struct'))%&& isfield(c_added_info,{'Time', 'Formants', 'StEndMatF','cmap_types', 'catagory', 'dbdown'}));
%assert(isa(c_added_info.Time,'double'));
%ssert(isa(c_added_info.Formants,'double'));
%assert(isa(c_added_info.dbdown,'double'));
%assert(isa(c_added_info.cmap_types,'double')&& size(c_added_info.cmap_types,2)==3);
%assert(isa(c_added_info.StEndMatF,'double')&& size(c_added_info.StEndMatF,2)==3);
%assert(isa(c_added_info.catagory,'double'));
%assert(isa(c_added_info,added_info4disp)) ;
% coder.extrinsic('cell2mat', 'display','ind2rgb','imagesc','mat2gray','clear');


%CONSTANT SETTING
dbdown = c_added_info.dbdown;
% doplot=true;
%noverlap=256;
%window=hamming(512);
% nfft = c_added_info.nfft;%2048;

% I. c_added_info build from the folowing fields
% II. c_Xin is a struct
if isempty(c_Xin.X) || isempty(c_Xin.t)|| isempty(c_Xin.f)
    try
        [c_Xin.X,c_Xin.t,c_Xin.f]=create_spec_mat_mex(x,fs);
    catch
        [c_Xin.X,c_Xin.t,c_Xin.f]=create_spec_mat(x,fs);
    end
    
end

% else
Xdb=c_Xin.X;
t=c_Xin.t;
f=c_Xin.f;
y_up = find(f>20000,1)  ;
y_dn = find(f>1000,1);
% end
% if (nargout==0) || doplot
Xmax = max(max(Xdb));
%     Xdb = double(20*log10(abs(X)));
%     Xmax = max(max(Xdb));
%Xmean = mean(Xdb(:));
%dbdown = - Xmean;
% Clip lower limit to -dbdown dB so nulls don't dominate:
clipvals = [Xmax,Xmax-dbdown];
I = mat2gray(Xdb,clipvals);
I= (I*10000);
I = cast(I,'uint32');

%cmap =colormap(gray(10000));
cmap =colormap(gray(10000));
RGB = ind2rgb(I,cmap);

% adding shape to images
if isempty(c_added_info.StEndMatF)
    % NO CALLS were found
    %cla(Axes);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    c_Xout.X=Xdb;
    c_Xout.t=t;
    c_Xout.f=f;
    c_added_info_out = c_added_info;
    %return
    %Types = 0;
else
    %         if ~isempty(c_added_info.catagory) % also classifier
    
    
    
    % check if data is classify (has 3 columns)
    
    %             if size(c_added_info.StEndMatF,2)<3
    %   display('data was not classified, display only segmentation');
    %  c_added_info.StEndMatF = [c_added_info.StEndMatF,ones(size(c_added_info.StEndMatF,1),1)];
    
    % end
    %             Types = unique(c_added_info.StEndMatF(:,3));
    %             c_added_info.cmap_types = colormap(hsv(max(Types)));
    %             if size(c_added_info.StEndMatF,2)==3
    Types = unique(c_added_info.StEndMatF(:,3));
    if all(Types==0)
        c_added_info.cmap_types = [0,0,0];
    else
        c_added_info.cmap_types = colormap(hsv(max(Types)));
    end
    %             else
    %                 c_added_info.catagory = zeros(length(c_added_info.StEndMatF),1);
    %                 Types =1;
    %                 c_added_info.cmap_types = [1 0 0];
    %                 c_added_info.StEndMatF(:,3)= ones(size(c_added_info.StEndMatF,1),1);
%end
%         else
% No classfication was made

% end

for ii =1:length(Types)
    
    tmp = c_added_info.StEndMatF(c_added_info.StEndMatF(:,3)==Types(ii),:);
%   [ tmp ] = Real_time( param, tmp, IDX, 0 );
    %if Types(ii)==(-1)
    %shapeInserter = vision.ShapeInserter('Shape','Polygons','BorderColor','Custom','Fill', true,'FillColor', 'Custom','CustomFillColor',[0,0,0]);
    
    %else
    %shapeInserter = vision.ShapeInserter('Shape','Polygons','BorderColor','Custom','Fill', true,'FillColor', 'Custom','CustomFillColor',c_added_info.cmap_types(Types(ii),:));
    %end
    
    %polyg = zeros(size(tmp,1),8);
    for kk=1:size(tmp,1)
        polyg(kk,1) = find(t>=tmp(kk,1),1); %x1
        polyg(kk,7) = polyg(kk,1);
        polyg(kk,3) = find(t>=tmp(kk,2),1); %x2
        polyg(kk,5) =polyg(kk,3);
        polyg(kk,2) = y_dn;
        polyg(kk,4)= y_dn;
        polyg(kk,8) = y_up; %x2
        polyg(kk,6) = y_up; %x2
    end
    if Types(ii)==(-1)|| Types(ii)==0
        RGB = insertShape(RGB, 'FilledPolygon', polyg, 'Color', [0,0,0], 'Opacity', 0.7);
        
    else
        RGB = insertShape(RGB, 'FilledPolygon', polyg, 'Color', c_added_info.cmap_types(Types(ii),:), 'Opacity', 0.7);
    end
    %RGB = step(shapeInserter, RGB, polyg);
    clear polyg
end
% end
if ~isempty(c_added_info.Time)&&~isempty(c_added_info.Formants)
    R = [3,3];%,3];
    color =[1,0,0;0,1,0];%;1,0,1];
    Time = cell2mat(c_added_info.Time(:));
    Formants =  cell2mat(c_added_info.Formants(:));
    TimeLoc = zeros(size(Time));
    FormLoc = zeros(size(Formants));
    for tt=1:length(Time)
        TimeLoc(tt) = find(t>=Time(tt),1);
        FormLoc(tt,1)=find(f>=Formants(tt,1),1);
        FormLoc(tt,2)=find(f>=Formants(tt,2),1);
%         FormLoc(tt,3)=find(f>=Formants(tt,3),1);
        %FormLoc(tt,3)=find(round(f/10^5, 3)>=round(Formants(tt,3)/10^5, 3),1);
    end
    
    
    for cr=1:2%3
        
        I = Formants(:,cr)>0;
        if any(I)
            tmpF = FormLoc(I,cr);
            tmpT = TimeLoc(I);
            tmpR = ones(length(tmpT),1)*R(cr);
            circlg = [tmpT(:),tmpF(:),tmpR(:)];
            RGB = insertShape(RGB,'FilledCircle', circlg, 'color', color(cr,:),'Opacity', 0.4);
            clear tmpF tmpT tmpR circlg
        end
    end
    
end
end
%%%%%%%%%%%

%%%%%%%%%%%
imagesc(t,f,RGB);
% grid;
axis('xy');hold on;
xlabel('Time (sec)');
ylabel('Freq (Hz)');
c_Xout.X=Xdb;
c_Xout.t=t;
c_Xout.f=f;
c_added_info_out = c_added_info;
end