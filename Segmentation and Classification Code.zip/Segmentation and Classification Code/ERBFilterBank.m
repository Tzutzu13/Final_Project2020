function y=ERBFilterBank(forward,feedback,x)
% y=ERBFilterBank(forward,feedback,x)
% This function filters the waveform x with the array of filters
% specified by the forward and feedback parameters. Each row
% of the forward and feedback parameters are the parameters
% to the Matlab builtin function "filter".
[rows, cols]=size(feedback);
y=zeros(rows,length(x));
for i=1:rows
 y(i,:)=filter(forward(i,:),feedback(i,:),x);
end