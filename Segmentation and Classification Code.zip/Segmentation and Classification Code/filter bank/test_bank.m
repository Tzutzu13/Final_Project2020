f=30001:125000;
ERB = 24.7*(4.37*f/1000 + 1);

% Glasberg & Moore
EARQ=1000/(24.7*4.37); %asymptotic filter quality at high freq
minBW=24.7; %min bandwidth for low freq
N=1;

% Lyon
EarBreak=1000;
EARQ=8; %asymptotic filter quality at high freq
minBW=EarBreak/8; %min bandwidth for low freq
N=2;


gen_ERB=((f/EARQ)^N+(minBW)^N)^(1/N);

%% test bank

impulse=[1 zeros(1,1023)];
[ERBforward,ERBfeedback, f]=MakeERBFilters(250000,90,35000);
y=ERBFilterBank(ERBforward,ERBfeedback,impulse);
response=20*log10(abs(fft(y(1:5:90,:)')));
freqScale=(0:1023)/1024*250000/1000;
figure
semilogx(freqScale(1:512),response(1:512,:))
axis([10^1.5 10^2.1 -40 5])
xlabel('Frequency [kHz]'); ylabel('Amp [dB]');
title('Gammatone filters');
