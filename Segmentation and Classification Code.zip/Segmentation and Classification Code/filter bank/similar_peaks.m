function [ freq ] = similar_peaks(peaks, f, energy, before)
% The function receives the energy peaks of the last 30 frames
% and searchs for a continuous peak
if before
    thresh=0.045;
    thresh2=0.1;
else
    thresh=0.063;
    thresh2=0.15;
end
p=[]; e=[];
for i=1:length(peaks)
    p=[p, cell2mat(peaks(i))];
    e=[e, cell2mat(energy(i))];    
end
U=unique(p); numbins=length(U);
[N,edges] = histcounts(p,numbins);
out=find(p<=15);
p(out)=[]; 
e_out=e; e_out(out)=[];
N=histcounts(p,edges);
%edges2=0:100:max(p.*e);
%[N2]=histcounts(p.*e, edges2);
[N2, I]=sort(N); dens=N2(end); bin_index=I(end)-1;
%[dens, bin_index]=max(N(2:end));
if dens>=floor(thresh*length(e))
    %p1=p.*e;
    %in_bin=p(p1>edges2(bin_index+1)&p1<edges2(bin_index+2)); 
    in_bin=p(p>=edges(bin_index+1)&p<=edges(bin_index+2)); 
    bin_energy_avg=mean(e(p>=edges(bin_index+1)&p<=edges(bin_index+2)));
    bin_energy_tot=sum(e(p>=edges(bin_index+1)&p<=edges(bin_index+2)));
    %bin_energy=min([bin_energy_med, bin_energy_avg]);
    if bin_energy_avg>0.7*mean(e) && bin_energy_tot>thresh2*sum(e_out) 
        % if bin_energy_med>100*(dens/length(e)) || bin_energy_avg>100*(dens/length(e))
        freq=[f(round(mean(in_bin))), 0, 0];
    else
        freq=[0, 0, 0];
    end
else
    freq=[0, 0, 0];
end
end

