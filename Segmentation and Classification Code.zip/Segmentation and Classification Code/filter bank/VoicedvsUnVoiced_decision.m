function [ decision ] = VoicedvsUnVoiced_decision( Voice, th )
% Inputs:
%   Voice - first peak amplitude in autocorrelation function calculated by
%   sift algorithm
%   th - threshold
% Outputs:
%   decision - logical vector: 0 for unvoiced, 1 for voiced

decision=zeros(length(Voice), 1);

for k=3:size(Voice, 1)
    if Voice(k)>th % if peak exceeds threshold determine voiced
        decision(k)=1;
        if ~decision(k-1) && decision(k-2) % if 1 unvoiced between 2 voiced determine voiced
            decision(k-1)=1;
        end
    else % if peak doesnt exceed threshold but previous 2 voiced check modified threshold
        if decision(k-1) && decision(k-2) 
            if Voice(k)>0.75*th
                decision(k)=1;
            end
        end
    end
end


end

