function [SybTime,SybForm,Formants,Time,ClassLPC,SyllableVec,Frames]=Syllables_Detection2(signal,Fs,p,signal_name)

%Input:
%properties/p = struct('FrameLength',0.009,'Overlap',0.7,'TH',6,'pr',0.5,'EnTH',0.3,'EnWin',100,'EnATH',5,'BW',[30000,115000],'order',10);
%signal - The recorded signal. No more than 9E6 samples.
%Fs - Sampling Frequency.

%Output:
%SybTime - Syllables location in seconds.
%Preprocessing

dbstop if error
flag_movie = 0;
ClassLPC = LPC_Formants_class;

[Frames,mind] = Framing(signal,Fs,p.FrameLength,p.Overlap);

SyllableVec = false*ones(size(Frames,1),1);
Formants = zeros(size(Frames,1),1);
AllFormant = zeros(size(Frames,1),3);
ERB_vec = zeros(size(Frames,1),1);

% time at center of each frame
Time = p.start_time+mind/Fs;
StartEndTime = [Time-p.FrameLength/2,Time+p.FrameLength/2];

% preparing the movie file
if flag_movie
    writerObj = VideoWriter([signal_name(1:end-4),'lpc_movie','.avi']);
    open(writerObj);
end % end flag_movie
[ERBforward,ERBfeedback, f]=MakeERBFilters(250000,90,35000);
%Max_Energy=zeros(size(mind)); %% adding max energy memory (10.2.17)
peaks=cell(1, length(Frames)); %% adding energy peaks memory (11.2)
count=0; count2=0;
for frm=1 : size(Frames,1)
    s=Frames(frm,:);
    if all(s==0)
        continue;
    end
    th=0.9; % first frequency energy threshold
    silence_th=p.thresh; % first frequency silence threshold
    [F, M]=Syllables_Detection_ERB(s,ERBforward,ERBfeedback, f, silence_th, th);
%     if any(F)
%         ERB_vec(frm)=1;
%     end
    %%%%%%%%% 17.03 exclude similar peaks search (for adults) %%%%%%%%
%      count=count+1;
%      if ~(any(F)) && count>20 
%          before=0;
%          if any(ERB_vec(frm-4:frm-1))
%              before=1;
%          end
%         %if length(find(AllFormant(frm-15:frm, 1)))>1 || count==21
%         if frm>25
%             F = similar_peaks(peaks(frm-25:frm), f, peaks_Energy(frm-25:frm), before);
%         else
%             F = similar_peaks(peaks(frm-20:frm), f, peaks_Energy(frm-20:frm), before);
%         end
%         if any(F)
%             SyllableVec(frm)=true;
%             if AllFormant(frm-1, 1)
%                 F(1)=mean([F(1), AllFormant(frm-1, 1)]);
%             end
%             count2=count2+1;
%             if count2==1 && AllFormant(frm-1, 1)
%                 last_syl_start=find(~(AllFormant(1:frm-1, 1)));
%                 if isempty(last_syl_start)
%                     count2=frm;
%                 else
%                     count2=frm-last_syl_start(end);
%                 end
%             end 
%         else
%             count2=0;
%         end
%         if count2==5
%             find_z=find(~(AllFormant(frm-20:frm-5, 1)));
%             AllFormant(find_z, 1)=mean(AllFormant(frm-4:frm-1, 1));
%             SyllableVec(frm-20:frm-5)=true;
%         end
%         if count2>=15
%             count2=0;
%             count=0;
%         end
%         %end
%     end
    %end
    %%%%%%%%%%%%%%%
    
    if any(F)
        SyllableVec(frm)=true;
        if length(find(F))==1%%&&F(find(F))<=6.25*10^4
            %th_2=0.01;
            th_2=p.harmony_th; 
            lowF=F(find(F)); lowF=lowF(1);
            %highF=min(lowF*2+5000, 125000);
            % in second round the frequencies are limited to 125kHz
            Filter_num=ceil((max(125000, lowF*2)-min(120000, lowF*2-2000))/(1.7*10^(3)));
            % 1.7*10^3 this is the bandwidth from the first round
            if Filter_num<3 %because can't find peaks if shorter than 3
                Filter_num=3;
            end
            [ERBforward_2,ERBfeedback_2, f_2]=MakeERBFilters(250000,Filter_num,min(120000, lowF*2-2000));
            F_2=Syllables_Detection_ERB(s,ERBforward_2,ERBfeedback_2, f_2, silence_th, th_2, M);
            if any(F_2)
               Fnew=[F_2(1), F(1:2)];
               F=sort(Fnew, 'descend'); 
            end
            %Fnew=[F(2:3), F_2(3)];
        end
        AllFormant(frm,:)=F;
    end % if any(F), end of first round
    
    if flag_movie
        if frm==1
            fig = figure('Visible','Off');
            set(fig,'Renderer','zbuffer')
            xlabel('Frequency [Hz]','fontsize',12) ;%Time [sec]
            ylabel('Power/Frequency [dB/rad/sample]','fontsize',12);
            ax = get(fig,'CurrentAxes');
            set(gca,'nextplot','replacechildren');
        end
        pl = plot(FreqVec,EstPSD,'r','linewidth',2);
        %set(pl,'color','r','linewidth',2)
        % plotting only if formant was found
        hold on
    end % if movie
    %if ~isempty(F)
        %SyllableVec(frm)=true;
        %AllFormant(frm,:)=F;
        %Formants(frm,:)=win_formant(1);
        %I =find(diff(win_formant)>Freq_var_rate);
        %win_formant =win_formant([1,I+1]);
        %if length(win_formant)>3
        %    N=3;
        %else
        %    N= length(win_formant);
        %end
        %Time(1,[i,i+1])=(mind(i)+mind2([st_ind,end_ind],1))./Fs;
        if flag_movie
            y=get(gca,'YLIM');
            line([Formants(frm),Formants(frm)],y,'Color','m'); hold on;
            for ii=2:length(win_formant)
                line([win_formant(ii),win_formant(ii)],y,'Color','b'); hold on;
            end
            title(Time(frm))
        end %end flag_movie
       
    %end %if ~isempty F
    
    if flag_movie
        F{frm} = fig;
        writeVideo(writerObj,getframe(fig));
        delete(pl);
        hline = findobj('type','line');
        delete(hline);
    end %flag_movie
    clear F
    clear F_2
    clear Fnew
end %for frm

if flag_movie
    close(writerObj);
    close(fig);
end

if ~any(SyllableVec)
    SybTime=[]; SybForm=[];
    return
else
    [~,Ind] = find((SyllableVec'));
    
    %SybTimet=Time(Ind);
    %DiffSybTimet=diff([0;SybTimet]);
    %deltaT= Time(2)-Time(1);
    %skipedframe = Ind(DiffSybTimet>(deltaT) & DiffSybTimet<=2*deltaT);
    diff_ind=diff([0, Ind]);
    skipedframe=Ind(diff_ind>1 & diff_ind<=4); 
    if ~isempty(skipedframe)
        %if length(skipedframe)>=2
        %skipedframe = skipedframe(2:end);
        for skip=1:length(skipedframe)
            SyllableVec(max(1,skipedframe(skip)-3):skipedframe(skip)-1) = true;
            %fix allformants in skipped frames
            before=find(AllFormant(1:skipedframe(skip)-1, 1),1,'last');
            %after=find(AllFormant(skipedframe(skip):end, 1),1,'first');
            after=skipedframe(skip);
            AllFormant(before+1:after-1)=mean([AllFormant(before), AllFormant(after)]);
        end
        %end
    end
    [~,Ind] = find((SyllableVec'));
    
    SybTime = Time(Ind);
    SybForm = Formants(Ind);
    ClassLPC.time = StartEndTime(Ind,:); %V
    
    % continuity
    [AllFormant] = frequency_continuity (AllFormant);

    ClassLPC.formant = AllFormant(Ind,:);%V %length of time X 3 (the 3 major formant detected in the time frame)
        
    ClassLPC.fileName = signal_name;
    ClassLPC.date = date;
    %ClassLPC.fileName = RecFilesNames;
    ClassLPC.window = p.FrameLength;
    ClassLPC.overlap = p.Overlap;
end

end 

