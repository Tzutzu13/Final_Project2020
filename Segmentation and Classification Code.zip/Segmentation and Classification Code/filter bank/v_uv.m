% histogram of silence vs voiced to choose threshold
load('C:\Users\Shaked\Google Drive\codes\output directory\16.04.16_2\bigData.mat');
[ERBforward,ERBfeedback, f]=MakeERBFilters(250000,90,35000);

Maximum=zeros(length(bigData.data), 1);
numPeaks=size(Maximum);
for V=2:32%length(bigData.data)
    string=['C:\Users\Shaked\Downloads\project\������\221115\5\newborn1 - red green\session1\Test_1\',...
        cell2mat(bigData.data(V, 1)), '.WAV'];
    [y, Fs]=audioread(string);
    syl_time=cell2mat(bigData.data(V, 4));
    %syl_formant=y((round(syl_time*Fs)));
    syl=y(round(syl_time(1)*Fs-2500):round(syl_time(end)*Fs)+1500);
    E=(ERBFilterBank(ERBforward,ERBfeedback,syl))';
    Energy=sum(E.^2);
    Maximum(V-1)=max(Energy);
    numPeaks(V-1)=length(findpeaks(Energy));
end

% Plot maximun energy distribution
%[P_m_s,bin_m_s] = ksdensity(Maximum(1:21));
[P_m_s,bin_m_s] = hist(Maximum(1:21));
figure
plot(bin_m_s,P_m_s);
hold on
%[P_m_v, bin_m_v]=ksdensity(Maximum(22:32));
[P_m_v, bin_m_v]=hist(Maximum(22:32));
plot(bin_m_v,P_m_v, 'r');

