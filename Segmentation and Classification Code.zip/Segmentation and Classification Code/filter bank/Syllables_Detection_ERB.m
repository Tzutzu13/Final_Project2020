function [  F , Max] = Syllables_Detection_ERB(signal,ERBforward,ERBfeedback, f, silence_th, th, M)
% This function detects frequency components of input syllables
% Input:


%signal=signal/max(signal);
f=f';
F=zeros(1, 3);
mean_Full_Energy=mean(signal.^2); 

E=(ERBFilterBank(ERBforward,ERBfeedback,signal))'; %% filter the signal through the filter bank, which each row is a result from one filter
Energy=sum(E.^2); % total energy after filtering the frames
Max=max(Energy);

Freq_var=length(find(Energy>0.2*max(Energy)));
if nargin==7
   %adjust silence threshold for 2nd frequency
   silence_th=silence_th-5; 
end

if Freq_var<=silence_th % if it's 1 than we've got vocal frame
    [p, ind]=findpeaks(Energy);
    thresh=th*max(Energy);
    peaks=ind(p>=thresh);
    if nargin==7 % if looking for harmony:          
        thresh=th*M;%adjust threshold
        %p=round(p, 5); thresh=round(thresh, 5);
        peaks=ind((p>=thresh)&(p>(10*mean_Full_Energy)));
        if isempty(p)
        %[p, ind]=max(Energy); %look for maximum instead of peak
        peaks=find((Energy>thresh)&(Energy>(100*mean_Full_Energy))); % look for any 
        end
        %peaks=ind(p>thresh);
    end
    if ~isempty(peaks) %organize frequencies     
        I=find(diff(peaks)<2);
        peaks(I+1)=[];
        if length(peaks)>=3
        F(:)=f(peaks(1:3));
        else
            if length(peaks)==2;
                F(:)=[f(peaks), 0];
            else 
                F(:)=[f(peaks), 0, 0]; 
        end    
    end
end

end

