function [ cell_signal,StartEndNew ] = Rearrange_signal( signal,Fs,StartEnd )
    
Between =[StartEnd(2:end,1)-StartEnd(1:end-1,2)];
StartEndNew = [StartEnd([1;Between]>0,1),StartEnd([Between;1]>0,2)];
%if nargin>3
%    ADD= varargin{1};
%  StartEndNew(:,1)= StartEndNew(:,1)-ADD;
%   StartEndNew(:,2)= StartEndNew(:,2)+ADD;
%end
Time = (0:length(signal)-1)/Fs;
cell_signal = cell(size(StartEndNew,1),1);

% enter signals cut to cells
for ii = 1:size(StartEndNew,1)
    time_part = find(Time<StartEndNew(ii,2) & Time >= StartEndNew(ii,1));
    cell_signal{ii} = signal(time_part);
    
end


end
