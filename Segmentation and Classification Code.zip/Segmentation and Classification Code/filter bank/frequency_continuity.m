function [x] = frequency_continuity (x)
% This function forces continuity of harmonics in syllables
% The condition for Harmony is at least 4 time frames where a harmony was
% found

i=1;
while i<=length(x)-3;
    if (x(i, 2))
        if x(i+1, 2) && x(i+2, 2)%% && x(i+3, 2)
            next=find(~x(i:end, 2))+i-1;
            if isempty(next)
                break
            end
            i=next(1)-1;
        else 
            x(i, 3)=x(i, 2);
            x(i, 2)=0;
        end
    end
    i=i+1;
    
end
% last 3 lines
if ~all(x(end-2:end, 2))
    x(i:end, 3)=x(i:end, 2);
    x(i:end, 2)=0;
end
x=sort(x, 2,'descend');                      

end
