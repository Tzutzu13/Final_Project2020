function [ StEndMatF ] = Real_time( param, StEndMatF, IDX, mode )
%The function attaches real time to all detected formants
% Inputs:
% param
% StEndMATF
% IDX - the number of the current track in the param singal list
% mode:
% mode=1 - to real time
% mode=0 - from real time

Dir=cell2mat(param.signal_path(IDX));
Track=strfind(Dir, '\');
Dir=Dir(1:Track(end)-1);
%Dir=Dir(1:end-12);
cd(Dir)
list=dir('*LOG');
f=fopen(list.name);
d=textscan(f, '%s %s %s %f %s', 'HeaderLines', 1);
fclose(f);
time=d(2);
l=d{1,4};
%time{1, 1}{1, 1}=[];
start_monitor=datevec(time{1, 1}{1, 1});
%start_monitor(1:3)=[];
T_name=cell2mat(param.signal_path(IDX));
T_num=str2num(T_name(end-7:end-4));
%StEndMatF=param.StEndMatF;
%for i=1:length(StEndMatF)
    if ~isempty(StEndMatF)
        stend=StEndMatF;
        start=datevec(time{1, 1}{T_num+1, 1});
        elapsed=etime(start,start_monitor);
%         if T_num~=1;
%             start_prev=datevec(time{1, 1}{T_num+1, 1});
%             prev=etime(start_prev,start_monitor);
%         end
%         if prev+l(T_num+1)>elapsed            
        if mode
            stend(:, 1:2)=stend(:, 1:2)+elapsed;
        else
            stend(:, 1:2)=stend(:, 1:2)-elapsed;
        end
        StEndMatF=stend;
    end        
%end
%param.StEndMatF=StEndMatF;
end

