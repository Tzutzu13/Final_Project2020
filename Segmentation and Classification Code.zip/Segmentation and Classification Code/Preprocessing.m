function [Signal1]=Preprocessing(Signal,Fs,varargin)
%INPUT:
%Signal - the given signal.
%Fs - Sampling Frequency.

%OUTPUT:
%Signal1- The Signal after Preprocessing.

%1. DC removal.
%2. :PF.

%1. DC REMOVAL
%==============
Signal= Signal-mean(Signal);

%2. low pass filter cutoff 120kHz %%%%%%%%
d = fdesign.lowpass('Fp,Fst,Ap,Ast',100*10^3,120*10^3,0.5,40,250*10^3);
Hd = design(d,'equiripple');
Signal1 = filter(Hd,Signal);



end %EOF.
