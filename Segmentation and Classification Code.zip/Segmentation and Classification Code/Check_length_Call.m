function [ New_Start_End,New_formants,New_time ] = Check_length_Call( Start_End,formants,time )
%Fix 2 Time Limits
% 1- proximity of two detections-> 1 Call!!
% 2- Normal length of Call
MIN_LENGTH = 0.01;
%MAX_LENGTH = 0.182;
MAX_LENGTH = 0.3;
MIN_BETWEEN_CALL = 0.017;%0.006;%0.005;
formants = formants(:);
time=time(:);
%INPUT_CHECK
if isempty(Start_End)
    New_Start_End = [];
    New_formants = [];
    New_time = [];
    return
end
% in case the length is over 1
if size(Start_End,1)>1
    %between calls Duration
    between = Start_End(2:end,1) - Start_End(1:end-1,2);
    
    %Indexs of less than minimum
    combineCalls = find(between<MIN_BETWEEN_CALL);
    % index of start and end!
    
    %combineCalls =[combineCalls(:),combineCalls(:)+1];
    %startpoint
    
    count = 1;
    ii=1;
    while ii<=size(Start_End,1)
        tmp(count,1) = Start_End(ii,1);
        tmpIdx = ii;
        OK = ismember(ii,combineCalls);
        if OK
            while ismember(ii,combineCalls)
                ii=ii+1;
            end
            tmp(count,2)= Start_End(ii,2);
            New_formants{count}=cell2mat(formants(tmpIdx:ii));
            New_time{count}=cell2mat(time(tmpIdx:ii));
            count= count+1;
        else
            tmp(count,2)= Start_End(ii,2) ;
            New_formants(count)=formants(ii);
            New_time(count) = time(ii);
            count= count+1;
            
        end
        ii=ii+1;
        
    end
else
    tmp = Start_End;
    New_formants = formants;
    New_time = time;
end
duration = tmp(:,2)-tmp(:,1);
Idx = find(duration>=MIN_LENGTH);% & duration<MAX_LENGTH);
New_Start_End = tmp(Idx,:);
New_formants = New_formants(Idx);
New_time = New_time(Idx);
kk=1;
idx=0;
Newer_formants=[];
%while kk+idx<=length(New_formants)
 %   tmp = preprocess_3DFormant(New_formants{kk});
  %  if isempty(tmp)
       % New_formants{kk}=tmp;
   %     tmp= New_time([1:kk-1,kk+1:end]);
    %    New_time= tmp;
     %   tmp=[];
      %  tmp= New_Start_End([1:kk-1,kk+1:end],:);
       % New_Start_End=tmp;
        %tmp=[];
        %idx=idx+1;
    %else
     %   Newer_formants{kk}=tmp;
      %  kk=kk+1;
    %end
%end
%New_formants  = Newer_formants;
end

