function [param, StEndMatF,formants] = Segmentation4Signal_2( param,IDX,varargin )
dbstop if error
global choice;
global EER
% VERSION PROPERTIES
str_pro = ['data : \tpreprocessing= bp\r\n new sub detection witout limits for formants\r\n TH1 :',num2str(param.TH1), 'TH2: ',num2str(param.TH2),'p1: ',num2str(param.p1),'p2: ',num2str(param.p2),'BW: ', num2str(param.Freq_Limits) ];
%Reading the files
%=================================

%===========================
% I.open files and logs
%======================

%TrialDir = fullfile(param.results_folder,['Trial_',num2str(param.trial),'_',date]);
TrialDir =param.results_folder;
if ~exist(TrialDir)
    mkdir(TrialDir);
end

log_name = fullfile(TrialDir,['Trial_',num2str(param.trial),'_',date,'.txt']);
if (IDX==1)
    f = fopen(log_name,'w'); %discard info from previous run
else
    f = fopen(log_name,'a'); %append info
end
if f==(-1)
    fclose all;
    if (IDX==1)
       f = fopen(fullfile(TrialDir,['Trial_',num2str(param.trial),'_',Date,'.txt']),'w');
    else
       f = fopen(fullfile(TrialDir,['Trial_',num2str(param.trial),'_',Date,'.txt']),'a');
    end
end
% writing to log file - log file is one for a trial number.
if IDX==1
    time = now;
    fprintf(f,'%s,\r\n',datestr(time));
end
% datestring = [num2str(param.date{IDX}(1)),'-',num2str(param.date{IDX}(2)),'-',num2str(param.date{IDX}(3))];
% fprintf(f,'Rec : %s\t,Date : %s\t,Channel : %d',param.signal_path{IDX},datestring,param.channel{IDX});
%-----------------------------------------------

%siz=audioread(param.signal_path{IDX},'size');
[SignalVec, Fs]=audioread(param.signal_path{IDX});
SignalVec = SignalVec-mean(SignalVec);


siz=size(SignalVec);
% in case that one signal contains more then 1 recording channels
SybCount=zeros(1,siz(2));

for s2=1 : siz(2)
        
    signal = SignalVec(:,s2);
    % PREPROCESSING
    % =============
    % only if the signal is yet preprocessed
    [~,filename,~] = fileparts(param.signal_path{IDX});
    
    if param.preprocessing
        if param.save_signal
            param.signal_path{IDX} =   fullfile(param.results_folder,[filename,'.wav']);
            signal = Preprocessing(signal,Fs,param.signal_path{IDX});
        else
            signal = Preprocessing(signal,Fs);
        end
    end
    
    if param.plot_flag
        param.signal{IDX}=signal;
    end
    % if there is a 'silent' start (zeros), skipping to the "real"
    % start .
    ind=find(signal==0);
    
    if ~isempty(ind) && ind(1)==1
        DiffInd = diff(diff(ind));
        ind2 = find(DiffInd~=0);
        if ~isempty(ind2)
            signal = signal(ind2(1):end);
        else
            ind2 = 1;%signal = signal(1:length(DiffInd));
        end
    else
        ind2=1;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
%%%%%%% 15.04.16 - changing algorithm from lpc to filter bank, only one round
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% FIRST ROUND 
%============
if choice ==2 %|| choice ==1
    properties = struct('FrameLength',0.006,'Overlap',0.7,'TH',param.TH1,'BW',param.Freq_Limits,'order',param.p1,'start_time',(ind2(1)-1)/Fs,'Freq_var_rate',0,...
        'thresh', 20, 'harmony_th', 0.009);%'harmony_th', 0.003);
    
    
    [~,~,~,~,ClassLPC,SyllableVec,~]= Syllables_Detection2(signal,Fs,properties,param.signal_path{IDX});
else
    if ~isempty(EER)
    properties = struct('FrameLength',0.0025,'Overlap',0.75,'start_time',(ind2(1)-1)/Fs,'silence_th',EER,'f_th',35000, 'harmony_th', 0.009);    
    [SyllableVec,~,ClassLPC] = segmentaion4adults( signal,properties,Fs);
    else
    properties = struct('FrameLength',0.0025,'Overlap',0.75,'start_time',(ind2(1)-1)/Fs,'silence_th',21,'f_th',35000, 'harmony_th', 0.009);    
    [SyllableVec,~,ClassLPC] = segmentaion4adults( signal,properties,Fs); 
    end
end
   %NOSYB_flag = false;
    StartEnd =[];
    formants = [];
    time_formant =[];
    if any(SyllableVec)
        realSylInd=0;
        [cell_signal,StartEndNew] = Rearrange_signal( signal,Fs,ClassLPC.time );
        % cell_signal-each array is the part in the original signal
        % StartEndNew - times vector
        
        h = findall(0,'Tag','TMWWaitbar');
        if isempty(h)
            h = waitbar(0,'wait...') ;
        else
            waitbar(0,h,[filename,'wait...']);
        end
        
        % LOOP ON ALL SIGNAL PARTS 
        %======================================
        StartEnd =[];
        formants = [];
        time_formant =[];
                 
        ns = 1;
        while ns<= size(StartEndNew,1)
            realSylInd = realSylInd+1;
            StartEnd{realSylInd}= StartEndNew(ns,:);
            TimeIDX = (ClassLPC.time(:,2)<=  StartEnd{realSylInd}(1,2)) & (ClassLPC.time(:,1)>=StartEnd{realSylInd}(1,1) ) ;
            formants{realSylInd}=ClassLPC.formant(TimeIDX,:);
            % [formants{realSylInd},err]= exclude_too_little_data(formants{realSylInd});
            %if err==1
            %   time_formant{realSylInd}=[];
            %   StartEnd{realSylInd} = [];
            %else
            time_formant{realSylInd}=ClassLPC.time(TimeIDX,1);
            % end
            ns = ns+1;
        end
    end                       
    StartEnd = StartEnd(:);
    StEndMatF = cell2mat(StartEnd);
    clear StartEnd SyllableVec2 SyllableVec StartEndNew cell_signal
        
    if ~isempty(StEndMatF)
        [ StEndMatF ,formants,time_formant] = Check_length_Call( StEndMatF,formants,time_formant );
        if ~isempty(StEndMatF)
            SybCount(s2)= size(StEndMatF,1);
        end
    end
        
    %end
    % writing data to log file
    %-------------------------
    fprintf(f,'total count: : %d,\r\n',SybCount(s2));
    for ii=1: SybCount(s2)
        fprintf(f,'%d\t%2.4f\t%2.4f\r\n',[ii, StEndMatF(ii,:)]);
    end
    fprintf(f,'\r\n');
    %-------------------------
    clear  SybForm SybTime  TimeVec FormVec
    
end %for s2

% save data if user requested to save raw data or, it is needed for classification
%----------------------------------------------------------------------
% merge all final data
if SybCount(s2)>0
    %adding zeros in the 3rd column (classfier column)
    StEndMatF = [StEndMatF,zeros(size(StEndMatF,1),1)];
    % correcting time
%      [ StEndMatF ] = Real_time( param, StEndMatF, IDX, 1 );
     param.StEndMatF{IDX} =  StEndMatF;
else
    param.StEndMatF{IDX} =  [];
end

if param.save_feautre && SybCount(s2)>0
    %%%% create filename %%%
    [pathstr, signal_name,~] = fileparts(param.signal_path{IDX}) ;
    % find indices in pathstr
    if choice == 1
        %%%%%%%       
        I_name = strfind(pathstr,'Batch');
        I_ch = strfind(pathstr,'\ch');
        name=pathstr(I_name:I_ch-1);
        I_endname=strfind(name, '\');
        %%%%%   nameA=name(I_endname(1)+1:end); if'll need is real name
        session = name(1:I_endname(1)-1);
        %%%%%%%
        date_i=regexp(pathstr, '\d');
        Date= pathstr(date_i(1:4)); 
        % combine strings
        name=[Date, '_Adult', '_', session, '_', signal_name];
        param.calls_feautre_mat{IDX} = [TrialDir '\', name,'.mat'];
        original_signal_path = param.signal_path{IDX};
%         save(param.calls_feautre_mat{IDX},'StEndMatF','formants','time_formant','original_signal_path');    
    else
        date_i=regexp(pathstr, '\d'); type_i=regexp(pathstr, 'newborn'); session_i=regexp(pathstr, 'session');
        % extract strings 
        Date=[pathstr(date_i(1:2)), '.', pathstr(date_i(3:4))];
        newborn=pathstr(type_i:type_i+8); session=pathstr(session_i:session_i+7);
        % combine strings
        name=[Date, '_', newborn, '_', session, '_', signal_name];
        param.calls_feautre_mat{IDX} = [TrialDir '\', name,'.mat'];
        original_signal_path = param.signal_path{IDX};
%         save(param.calls_feautre_mat{IDX},'StEndMatF','formants','time_formant','original_signal_path');
    end
end
% printing data
if nargin==2
    fprintf(f,'\r\n\r\n');
elseif nargin ==3 && strcmpi(varargin{1},'end')
    fprintf(f,['\r\n\r\n',str_pro]);
    %
    close(findall(0,'Tag','TMWWaitbar'));
    param.StEndMatF = param.StEndMatF(:);
    tmp = cell2mat(param.StEndMatF);
    param.Num_calls = size(tmp,1);
end
fclose(f);
end

