function [F]=Check_Threshold(s, th, th_2) 
%th=1.5*10^(-4); % default threshold
    [ERBforward,ERBfeedback, f]=MakeERBFilters(250000,90,35000);
    [F, M]=Syllables_Detection_ERB(s,ERBforward,ERBfeedback, f, 20, th);
    if any(F) 
        %second round
        if length(find(F))==1&&F(find(F))<=6.25*10^4
            thresh_2=th_2;
            lowF=F(find(F)); lowF=lowF(1);
            Filter_num=ceil((125000-(lowF*2-2000))/(1.7*10^(3)));
            if Filter_num<3 %because can't find peaks if shorter than 3
                Filter_num=3;
            end
            [ERBforward_2,ERBfeedback_2, f_2]=MakeERBFilters(250000,Filter_num,lowF*2-2000);
            F_2=Syllables_Detection_ERB(s,ERBforward_2,ERBfeedback_2, f_2, 20, thresh_2, M);
            Fnew=[F(2:3), F_2(3)];
            F=sort(Fnew);                      
        end
    end