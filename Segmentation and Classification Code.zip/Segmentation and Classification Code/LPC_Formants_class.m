classdef LPC_Formants_class
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        date
        fileName
        window
        overlap
        time %sec
        formant %length of time X 3 (the 3 majer formant detected in the time frame
        preprocessing = ''; % a log string containing all the information about the preprocessing
        
    end
    
    methods
        function obj=get_timestamp(obj)
            obj.date = date;
        end
    end
    
end

