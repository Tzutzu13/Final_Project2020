% filter bank

[y, Fs]=audioread('C:\Users\Shaked\Downloads\project\MTHFR USV\recordings_05_28\first_3_couples\ch5\T2013-05-28_19-32-08_0000012.WAV');
%syl_time=cell2mat(bigData.data(1, 4));
%syl_time=Man_startend(7, :)
%syl_formant=y((round(syl_time*Fs)));
%syl_time=[2.1609, 2.2242]; %% for t5
%syl_time=[2.5176, 2.5404]; %% for t6
%syl_time=[0.20974, 0.24491]; %% for t7
syl_time=[1.2634, 1.2815];
syl=y(round(syl_time(1)*Fs-500):round(syl_time(end)*Fs+500));
%syl=y(round(5.2*Fs):round(5.3*Fs)+10000);

figure
spectrogram(syl, 1024, 512, 1024, Fs, 'yaxis');
colormap jet

[newSignalFrames,mind]= Framing(syl,Fs,0.006,0.7);
F=zeros(size(mind, 1), 3);
th=0.9;
%th_2=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];
th_2=0.01;
for i=1:size(newSignalFrames, 1)
    %for j=1:9;
    F(i, :)  = Check_Threshold(newSignalFrames(i, :), th, th_2);
    %end
end


[ERBforward,ERBfeedback, f]=MakeERBFilters(250000,90,35000);
f=f';
Energy=zeros(size(mind, 1), 90);
F=zeros(size(mind, 1), 3);
for i=1:size(newSignalFrames, 1)
    Full_Energy(i)=sum(newSignalFrames(i, :).^2);
    E=(ERBFilterBank(ERBforward,ERBfeedback,syl))';
    Energy=sum(E.^2);
     figure
plot(f/1000, Energy)
title('Energy of filter bank outputs'); 
xlabel('Amp'); ylabel('Freq [kHz]');
    [p, ind]=findpeaks(Energy);
    peaks=ind(p>1.5*10^(-4));
    if isempty(peaks)
        continue
    end
    if length(peaks)>=3
    F(i, :)=f(peaks(1:3));
    else
        if length(peaks)==2;
        F(i, :)=[f(peaks), 0];
        else 
        F(i, :)=[f(peaks), 0, 0];
        end
    end
    F(i, :)=sort(F(i, :));
end

for j=1:length(Freq)-29
    windows=[windows; Freq(j:j+29)];
end
figure
Time=mind/Fs;
subplot(2, 1, 2)
plot(Time, Value, 'r')
title('Energy value')
subplot(2, 1, 1)
plot(Time, Freq)
title('Frequency')

for j=7:length(F)
    if ~F(j, 1)
        if F(j-6:j-1, 1)
            F(j, 1)=Freq(j);
        end
    end
end
