function [X,t,f] = create_spec_mat(x_in,fs)
%#codegen
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%assert(isa(x,'double')&& (size(x,2) == 1));
%assert(isa(fs,'double'));
%assert(isa(Xout,'struct'));
%assert(isa(Xout.X,'double'));
%assert(isa(Xout.t,'double'));
%assert(isa(Xout.f,'double'));
%dbdown = c_added_info.dbdown;
%doplot=true;
noverlap = 256;
window = hamming(512);
nfft = 2048;

coder.varsize('x',[2000000,1]);
coder.varsize('X',[2048,200000]);
coder.varsize('t',[1,200000]);
coder.varsize('f',[1,2048]);
% x=x_in;
M = length(window);
%x_match = zeros(M,1);
if (M<2)
    error('myspectrogram: Expect complete window, not just its length');
end;
if (M<2)
    error('myspectrogram: Expect complete window, not just its length');
end
if length(x_in)<M % zero-pad to fill a window:
    x = cat(1,x_in,zeros(M-length(x_in),1));
else
    x = x_in;
end
Modd = mod(M,2); % 0 if M even, 1 if odd
Mo2 = (M-Modd)/2;
w = window(:); % Make sure it's a column

if noverlap<0
    nhop = - noverlap;
    %noverlap = M-nhop;
else
    nhop = M-noverlap;
end

nx = length(x);
%nframes = 1+floor((nx-noverlap)/nhop);
nframes = 1+ceil(nx/nhop);

Xout = complex(zeros(nfft,nframes)); % allocate output spectrogram

zp = zeros(nfft-M,1); % zero-padding for each FFT

xoff = 0 - Mo2; % input time offset = half a frame
xoff = (0 - Mo2):nhop:nframes*nhop+xoff;
for m=1:nframes
    %  M,Mo2,xoff,nhop
    xframe = zeros(M,1);
    if xoff(m)<0
        xframe(1:xoff(m)+M) = x(1:xoff(m)+M); % partial input data frame
    else
        if xoff(m)+M > nx
            xframe = [x(xoff(m)+1:nx);zeros(xoff(m)+M-nx,1)];
        else
            xframe = x(xoff(m)+1:xoff(m)+M); % input data frame
        end
    end
    xw = w .* xframe; % Apply window
    xwzp = [xw(Mo2+1:M);zp;xw(1:Mo2)];
    Xout(:,m) = fft(xwzp);
    
  
end
X = double(20*log10(abs(Xout(1:end/2,:))));
%X = double(20*log10(abs(X)));
t = (0:nframes-1)*nhop/fs;
%f = (0:nfft/2-1)*fs/nfft;
f = (1:nfft/2)*fs/nfft;

end

