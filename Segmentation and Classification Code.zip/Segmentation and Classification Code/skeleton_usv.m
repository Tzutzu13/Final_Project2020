function [param, err_flag ] = skeleton_usv( param )
%INPUT
%-----
% param is a class that - all his properties can be gathered from a
% designed GUI.
% OUTPUT
%-------
% err_flag
% in case there was an error
%===========================================
%% STEP I   - create output dir, and open a log file
%===========================================
err_flag = 1;
dbstop if error

if ~isdir(param.results_folder)
    mkdir(param.results_folder)
end
%===========================================
%% Check which kind of subjects we have:
global choice;
global EER
choice = 2;
%% STEP X. - ROC
%==========================================
% if param.roc
% %     [Pd, Pf, TotNd, TotNm, TotNf] = create_ROC( param, 1 );
% 
%      [Pf,Pd,EER,ind,TNR,PPV,NPV,Acc  ] = error_check( param );
%         %
%         %[Pf,Pd,EER,ind,TNR ] = errCheckForOldRecs( param )
%         %
%     figure;plot([0 Pf(1:end-1) 1],[0 Pd(1:end-1) 1],'-o','Linewidth',1);
%     
%     
%     hold on;
%  x = [Pf(end) 1];
% y = [Pd(end-1) Pd(end)];
% line(x,y,'LineWidth',1);
% %     plot(line([0 0],[1 1]));
%     xlim([0 1]);
%     ylim([0 1]);
% %     grid on;
%     xlabel('False Positive Rate'); ylabel('True Positive Rate');
%     AUC = trapz([0 Pf 1],[0 Pd 1]);
%     title('ROC curve');
%     hold on;
%     plot(Pf(ind),Pd(ind),'r*','Linewidth',1.5); gtext(['AUC=' num2str(AUC)]);
% end
%% STEP II   -  segmentation and preprocessing
%===========================================
% LOOP ON ALL SIGNALS
if param.segmantation
    for ii= 1: length(param.signal_path)-1
        
        [ param]    = Segmentation4Signal_2( param,ii );
        
    end     % end of loop
    param   = Segmentation4Signal_2( param,length(param.signal_path),'end' );
    %[ param ] = Real_time( param );
    if ~isempty(param)
      err_flag = 0;
    end
end %end of step II
%===========================================

%% preSTEP III
%===========================================
if (param.classification)%||param.roc) && ~param.segmantation
    log_name = fullfile(param.results_folder,['Trial_',num2str(param.trial),'_',date,'.txt']);
    
    % move all calls feature to result_folder
    for ii=1:numel(param.calls_feautre_mat)
        [~,pure_name,ext] = fileparts(param.calls_feautre_mat{ii});
        if ~strcmpi(param.calls_feautre_mat{ii},fullfile(param.results_folder,[pure_name,ext]))
            copyfile(param.calls_feautre_mat{ii},fullfile(param.results_folder,[pure_name,ext]));
            param.calls_feautre_mat{ii} = fullfile(param.results_folder,[pure_name,ext]);
        end
    end
    % and create LOG file
    if ~exist(log_name,'file')
        [ err_flag,param.signal_path] = dir2txtlog( param.calls_feautre_mat,log_name );
        if err_flag
            error('some error happend during txt log file creation');
        end
    end
        % loop on all feautre mat to load signal path
        for ii=1:numel(param.calls_feautre_mat)
            load(param.calls_feautre_mat{ii});
            try
                param.signal_path{ii,1} = original_signal_path;
                param.StEndMatF{ii,1} = StEndMatF;
            catch
                display('MAT File is not in the right format , check your input')
                return;
            end
            clear original_signal_path  StEndMatF
        end
end

%===========================================
%% STEP IX. - classification \ if  required
%===========================================
if param.classification
    if isempty(param.model_feature)&& (~isempty(param.model_path))
        param =load_feature_from_path(param,param.model_path,'model_feature');
    end
    [ label_vec ] = DTW_classifier( bigData.data(:,bigData.headers.FORMANT_3D) , param.model_feature);
    if ~isempty(label_vec)        
        bigData.data(:,bigData.headers.LABEL) = mat2cell(label_vec(:),ones(length(label_vec),1),1);
        param  = datastruct2file( param,bigData );
        save(fullfile(param.results_folder,'Labeled_Data'),'bigData');
    end
end %end of step IX
end     % end of skeleton

