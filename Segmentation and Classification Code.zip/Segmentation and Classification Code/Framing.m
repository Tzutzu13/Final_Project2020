function [newSignalFrames,mind]= Framing(signal,Fs,FrameLength,Overlap)
%newSignalFrames - The new signal's Frames.
%mind - The time in samples at the centre of each frame.

%1.Framing
%==========
win = FrameLength*Fs; 
inc = round((Overlap)*win);
[signalMAT ,mind]= enframe(signal,win,inc);

%2.Window
%===========
% creating hamming filter window (TIME SPEC)
w = hamming(win); 
W = repmat(w,1,size(signalMAT,1));  
newSignalFrames = signalMAT.*W';

%newSignal=Signal2(2:end);
end