# -*- coding: utf-8 -*-
"""
Created on Mon Apr 15 10:52:04 2019

@author: renan
"""

from __future__ import print_function
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K
import matplotlib.pyplot as plt
import ReadingAudio
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix
import random
from scipy.ndimage import shift
# from Aug_size import Aug_size

# import matplotlib.pyplot as plt
# for i in range(1,3):
#     plt.figure()
#     # plt.title(y_test[i], fontsize = '20')
#     plt.imshow(Data[i], origin = 'lower', cmap='hot')
# np.save('TrainTrueLabels',y_train)
# np.save('TestTrueLabels',y_test)
# np.save('trainData',trainData)
# np.save('testData',testData)

# TrainTrueLabels = np.load('TrainTrueLabels.npy',allow_pickle=True)
# TestTrueLabels = np.load('TestTrueLabels.npy',allow_pickle=True)
# trainData = np.load('trainData.npy',allow_pickle=True)
# testData = np.load('testData.npy',allow_pickle=True)

batch_size = 64
num_classes = 2
epochs = 50

# input image dimensions
img_rows, img_cols = 64, 64

excel_train = r"C:\Users\omrim\Desktop\פרויקט הנדסי\Codes 2019-2020\active learning\train_lables.xlsx"
(trainData,TrainTrueLabels)=ReadingAudio.ReadingAudio(excel_train,1)

excel_test = r"C:\Users\omrim\Desktop\פרויקט הנדסי\Codes 2019-2020\active learning\test_lables.xlsx"
(testData,TestTrueLabels)=ReadingAudio.ReadingAudio(excel_test,2)

i=0
# num_complex=0
# num_upward=0
x_train = [None] * len(trainData)
y_train = [None] * len(trainData)

for ind in range(0, len(trainData)): 
    if TrainTrueLabels[ind]== 'Complex':
        x_train[i]=trainData[ind]
        y_train[i]= 0 # Complex = 1
        i+=1
        # num_complex+=1
    elif TrainTrueLabels[ind]== 'Frequency Steps':
        x_train[i]=trainData[ind]
        y_train[i]= 1 # Frequency Steps = 2
        i+=1

x_test = [None] * len(testData)
y_test = [None] * len(testData)

for ind in range(0, len(testData)):
    if TestTrueLabels[ind]== 'Complex':
        x_test[ind]=testData[ind]
        y_test[ind]= 0 # Frequency Steps = 1
        # i+=1
        # num_complex+=1
    if TestTrueLabels[ind]== 'Frequency Steps':
        x_test[ind]=testData[ind]
        y_test[ind]= 1 # Upward = 2
        # i+=1

testLables = y_test
x_val = x_test[400:600]
y_val = testLables[400:600]
x_train=[x for x in x_train if x is not None]
y_train=[x for x in y_train if x is not None]

# def shift_image(image, dx, dy):
#     image = image.reshape((32, 32))
#     shifted_image = shift(image, [dy, dx], cval=0, mode="constant")
#     return shifted_image

# # Creating Augmented Dataset
# x_train_augmented = [image for image in x_train]

# j = 0
# for dx, dy in ((1,0), (-1,0), (0,1), (0,-1)):
#      for image in zip(x_train):
#              x_train_augmented.append(shift_image(image[0], dx, dy))
#              y_train.append(y_train[j])
#              j += 1
#      j = 0
# x_train = np.asarray(x_train_augmented)

 #Augmentation:
       
#if num_complex<num_upward:
#    DataNew=Aug_size((num_upward-num_complex),'Complex',Data,TrueLabels)    
#if num_upward<num_complex:
#    DataNew=Aug_size((num_complex-num_upward),'Upward',Data,TrueLabels)    
    
#if num_complex<num_upward:
#    labels=[1]*(num_upward-num_complex)
#if num_upward<num_complex:
#    labels=[2]*(num_complex-num_upward)
#
#x_train=x_train+DataNew    
#y_train=y_train+labels

# random.seed(4)
# random.shuffle(x_train)
# random.seed(4)
# random.shuffle(y_train)

# random.seed(3)
# random.shuffle(x_test)
# random.seed(3)
# random.shuffle(y_test)

# num_of_test_samples=int(np.floor(0.15*len(x_train)))
# x_test=x_train[0:num_of_test_samples]
# x_train=x_train[(num_of_test_samples+1):len(x_train)]

# y_test=y_train[0:num_of_test_samples]
# y_train=y_train[(num_of_test_samples+1):len(y_train)]

# start_num = 0
# num_of_test_samples = 100
# x_test = testData[start_num:start_num + num_of_test_samples]
# y_test = testLables[start_num:start_num + num_of_test_samples]

y_test = np.asarray(y_test)
y_train = np.asarray(y_train)
x_train=np.asarray(x_train)
x_test=np.asarray(x_test)
x_val=np.asarray(x_val)
y_val=np.asarray(y_val)

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    x_val = x_val.reshape(x_val.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols,1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols,1)
    x_val = x_val.reshape(x_val.shape[0], img_rows, img_cols,1)
    input_shape = (img_rows, img_cols, 1)

x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_val = x_val.astype('float32')
x_train /= 255
x_test /= 255
x_val /= 255

x_test1 = x_test[200:400]
x_test2 = x_test[400:600]

print('x_train shape:', x_train.shape)
print(x_train.shape[0], 'train samples')
print(x_test.shape[0], 'test samples')

# for i in range(18,23):
#     plt.figure()
#     plt.pcolormesh(x_test[i],cmap = 'terrain')

y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)
y_val = keras.utils.to_categorical(y_val, num_classes)

y_test1 = y_test[0:200]
y_test2 = y_test[200:400]
# from numpy.random import seed
# seed(1)
# from tensorflow import set_random_seed
# set_random_seed(2)

model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3),
                  activation='relu',
                  input_shape=input_shape))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(num_classes, activation='softmax'))

CallBack=keras.callbacks.EarlyStopping(monitor='val_acc', min_delta=0, patience=8, verbose=0, mode='auto', baseline=None, restore_best_weights=True)
# from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau
# def set_callbacks( name = 'best_model_weights',patience=8,tb_base_logdir='./logs/'):
#     from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau
#     cp = ModelCheckpoint(name +'.h5',save_best_only=True)
#     es = EarlyStopping(patience=patience,monitor='val_loss')
#     rlop = ReduceLROnPlateau(patience=8)
#     return [rlop, es, cp]

model.compile(loss=keras.losses.categorical_crossentropy,
              optimizer=keras.optimizers.Adagrad(lr=0.012),
              metrics=['accuracy'])

history=model.fit(x_train, y_train,
          batch_size=batch_size,
          epochs=20,
          verbose=1,
          validation_data=(x_val, y_val),
          callbacks = [CallBack])
# score = model.evaluate(x_test, y_test_cat, verbose=0)

# print('Test loss:', score[0])
# print('Test accuracy:', score[1])

# list all data in history
print(history.history.keys())
# summarize history for accuracy
plt.figure(0)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.savefig('Original Accuracy.jpg')
# summarize history for loss
plt.figure(1)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'validation'], loc='upper left')
plt.savefig('Original Loss.jpg')

#Confution Matrix and Classification Report
Y_pred = model.predict(x_test1)
y_pred = np.argmax(Y_pred, axis=1)
# print('Confusion Matrix')
# print(confusion_matrix(y_test, y_pred))
# print('Classification Report')
# target_names = ['Complex', 'Frequency Steps']
# print(classification_report(y_test1, y_pred, target_names=target_names))

# from sklearn.metrics import accuracy_score
# accuracy_score(y_test, y_pred, normalize=False)

from cm_analysis import cm_analysis
cm_analysis(testLables[200:400], y_pred, 'confusion matrix', [0,1])

# active learning
# x_train = np.concatenate((x_train,x_test),axis=0)
# y_train = np.concatenate((y_train,y_pred),axis=0)

Y_pred = model.predict(x_test2)
y_pred = np.argmax(Y_pred, axis=1)

from LeastConfidenceSyllables import sortLC
x_LC,ind_LC = sortLC(y_pred,Y_pred,x_test2)
import scipy.io
# test_LC = [ind_LC+1,[start_num,num_of_test_samples],y_pred]
test_LC = [ind_LC+1,[400,200],y_pred]
test_LC = np.asarray(test_LC)
scipy.io.savemat('test_LC.mat', {'mydata': test_LC})

# y_LC = scipy.io.loadmat('pred_syll.mat')
# y_LC = y_LC['spec_pred']
# y_LC = y_LC.reshape(y_LC.shape[0])
# y_train = np.concatenate((y_train,y_LC),axis=0)
# x_train = np.concatenate((x_train,x_LC),axis=0)

