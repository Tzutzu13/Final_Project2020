function [ newData ] = Convert2Syllable( data , y_pred )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% temp = {};
for i = 1:length(y_pred)
    switch y_pred(i)
        case 0
%             temp{i} = 'Complex';
              temp(i) = "Complex";
        case 1
%             temp{i} = 'Frequency Steps';
              temp(i) = "Frequency Steps";
        case 2
%             temp{i} = 'Upward';
              temp(i) = "Composite";
        case 3
%             temp{i} = 'Upward';
              temp(i) = "Chevron";

        case 99
%             temp{i} = '99';
              temp(i) = "99";

    end
end

% newData = [data,temp'];
newData = temp';
end

