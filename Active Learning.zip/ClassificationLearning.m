function varargout = ClassificationLearning(varargin)
% CLASSIFICATIONLEARNING MATLAB code for ClassificationLearning.fig
%      CLASSIFICATIONLEARNING, by itself, creates a new CLASSIFICATIONLEARNING or raises the existing
%      singleton*.
%
%      H = CLASSIFICATIONLEARNING returns the handle to a new CLASSIFICATIONLEARNING or the handle to
%      the existing singleton*.
%
%      CLASSIFICATIONLEARNING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CLASSIFICATIONLEARNING.M with the given input arguments.
%
%      CLASSIFICATIONLEARNING('Property','Value',...) creates a new CLASSIFICATIONLEARNING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ClassificationLearning_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ClassificationLearning_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ClassificationLearning

% Last Modified by GUIDE v2.5 23-Jun-2020 18:06:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ClassificationLearning_OpeningFcn, ...
                   'gui_OutputFcn',  @ClassificationLearning_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ClassificationLearning is made visible.
function ClassificationLearning_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ClassificationLearning (see VARARGIN)

% Choose default command line output for ClassificationLearning
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

global range
global ind_LC
global data
global idx
global pred
global y_pred
global spec_pred

spec_pred = [];
fromPython = struct2array(load('test_LC'));
range = fromPython{1,2};
range = [range(1)+1,range(1)+range(2)];
ind_LC = fromPython{1,1};
y_pred = fromPython{1,3};
idx = 1;

set(handles.start_text,'String',range(1));
set(handles.end_text,'String',range(2));
set(handles.num_index,'String',strcat(num2str(idx),"/",num2str(length(ind_LC))));

% [num,row,data] = xlsread('goldStandarts2020');
startN = range(1);
endN = range(2);
str = strcat('A',num2str(startN),':','I',num2str(endN));
[~,~,data] = xlsread('test_lables',str);
% [~,~,data] = xlsread('train_lables',str);
% data = data(startN:1:endN,:);
set(handles.index_text,'String',ind_LC(idx));

pred = Convert2Syllable(data,y_pred);
set(handles.syllprev,'String',pred(ind_LC(idx)));

% plotting the signal
path = strcat(data{ind_LC(idx),1},'/',data{ind_LC(idx),2},'.wav');
[signal, Fs] = audioread(path);
N = Fs;
f = figure('visible','off');
signal = signal(data{ind_LC(idx),3}*N:data{ind_LC(idx),4}*N);
spectrogram(signal,256,120,256,Fs,'MinThreshold',-110,'yaxis');
set(gca,'Visible','Off')
saveas(f,'syll.jpg')  % here you save the figure
myImage = imread('syll.jpg');
set(handles.axes_spectogram,'Units','pixels');
axes(handles.axes_spectogram);
imshow(myImage);
set(handles.axes_spectogram,'Units','normalized');

% image show
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');

str = strcat('I',num2str(range(1)),':','I',num2str(range(2)));
xlswrite('test_lables.xlsx',pred,str)   

% --- Outputs from this function are returned to the command line.
function varargout = ClassificationLearning_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in startbutton.
function startbutton_Callback(hObject, eventdata, handles)
% hObject    handle to startbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in upward.
function upward_Callback(hObject, eventdata, handles)
% hObject    handle to upward (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of upward

% image show
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');

% --- Executes on button press in complex.
function complex_Callback(hObject, eventdata, handles)
% hObject    handle to complex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of complex

% image show
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');

% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global range
global ind_LC
global data
global idx
global pred
global y_pred
global spec_pred

syllable = get(handles.buttonGroup.SelectedObject,'String');
pred(ind_LC(idx)) = syllable;
num_syllable = get(handles.buttonGroup.SelectedObject,'UserData');
y_pred(ind_LC(idx)) = num_syllable;
spec_pred(idx,1) = num_syllable;

% exp2
% xlsappend('train_lables.xlsx',[data(ind_LC(idx),1),data(ind_LC(idx),2),...
%     data(ind_LC(idx),3),data(ind_LC(idx),4),data(ind_LC(idx),5),...
%     data(ind_LC(idx),6),data(ind_LC(idx),7),data(ind_LC(idx),8),syllable])

if idx == length(ind_LC)
    set(handles.save,'Visible','Off');
    str = strcat('I',num2str(range(1)),':','I',num2str(range(2)));
    xlswrite('test_lables.xlsx',pred,str)
%     xlswrite('train_lables.xlsx',pred,str)
    
    % exp 2
    save('pred_Syll','spec_pred')
    % exp 3
%     save('pred_Syll','y_pred')
    msgbox('Operation Completed');    
else
    idx = idx + 1;
    set(handles.syllprev,'String',pred(ind_LC(idx)));
    
    % plotting the signal
    path = strcat(data{ind_LC(idx),1},'/',data{ind_LC(idx),2},'.wav');
    [signal, Fs] = audioread(path);
    N = Fs;
    f = figure('visible','off');
    signal = signal(data{ind_LC(idx),3}*N:data{ind_LC(idx),4}*N);
    spectrogram(signal,256,120,256,Fs,'MinThreshold',-110,'yaxis')
    set(gca,'Visible','Off')
    saveas(f,'syll.jpg')  % here you save the figure
    myImage = imread('syll.jpg');
    set(handles.axes_spectogram,'Units','pixels');
    axes(handles.axes_spectogram);
    imshow(myImage);
    set(handles.axes_spectogram,'Units','normalized');
    set(handles.index_text,'String',ind_LC(idx));
    set(handles.num_index,'String',strcat(num2str(idx),"/",num2str(length(ind_LC))));
    
    % image show
    syllable = get(handles.buttonGroup.SelectedObject,'String');
    myImage = imread(strcat(syllable,'.jpg'));
    set(handles.axes_pic,'Units','pixels');
    resizePos = get(handles.axes_pic,'Position');
    myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
    axes(handles.axes_pic);
    imshow(myImage);
    set(handles.axes_pic,'Units','normalized');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of start as text
%        str2double(get(hObject,'String')) returns contents of start as a double


% --- Executes during object creation, after setting all properties.
function start_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in class99.
function class99_Callback(hObject, ~, handles)
% hObject    handle to class99 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of class99
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');

% --- Executes during object creation, after setting all properties.
function axes_pic_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_pic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_pic


% --- Executes during object creation, after setting all properties.
function buttonGroup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to buttonGroup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% displaying image


% --- Executes during object creation, after setting all properties.
function axes_spectogram_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_spectogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_spectogram


% --- Executes on button press in flat.
function flat_Callback(hObject, eventdata, handles)
% hObject    handle to flat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of flat
% image show
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');

% --- Executes on button press in chevron.
function chevron_Callback(hObject, eventdata, handles)
% hObject    handle to chevron (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chevron
% image show
syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');


% --- Executes on button press in frequencySteps.
function frequencySteps_Callback(hObject, eventdata, handles)
% hObject    handle to frequencySteps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of frequencySteps

syllable = get(handles.buttonGroup.SelectedObject,'String');
myImage = imread(strcat(syllable,'.jpg'));
set(handles.axes_pic,'Units','pixels');
resizePos = get(handles.axes_pic,'Position');
myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
axes(handles.axes_pic);
imshow(myImage);
set(handles.axes_pic,'Units','normalized');
