# -*- coding: utf-8 -*-
"""
Created on Fri May  8 12:24:18 2020

@author: omrim
"""
import numpy as np

def sortLC(y_pred,Y_pred,x_test):
    size = len(y_pred)
    x_LC = size * [None]
    ind_LC = size * [None]
    j = 0
    
    for i in range(0,size):
        if y_pred[i] == 0 and Y_pred[i][0]<0.8:
            x_LC[j] = x_test[i]
            ind_LC[j] = i
            j+=1
        if y_pred[i] == 1 and Y_pred[i][1]<0.8:
            x_LC[j] = x_test[i]
            ind_LC[j] = i
            j+=1
        if y_pred[i] == 2 and Y_pred[i][2]<0.8:
            x_LC[j] = x_test[i]
            ind_LC[j] = i
            j+=1
    x_LC=[x for x in x_LC if x is not None]
    ind_LC=[x for x in ind_LC if x is not None]    
    x_LC=np.asarray(x_LC)
    ind_LC=np.asarray(ind_LC)
    # x_test = x_test.reshape(size,32,32)
    return (x_LC,ind_LC)
            



