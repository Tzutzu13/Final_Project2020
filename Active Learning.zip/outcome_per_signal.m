function varargout = outcome_per_signal(varargin)
% OUTCOME_PER_SIGNAL MATLAB code for outcome_per_signal.fig
%      OUTCOME_PER_SIGNAL, by itself, creates a new OUTCOME_PER_SIGNAL or raises the existing
%      singleton*.
%
%      H = OUTCOME_PER_SIGNAL returns the handle to a new OUTCOME_PER_SIGNAL or the handle to
%      the existing singleton*.
%
%      OUTCOME_PER_SIGNAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OUTCOME_PER_SIGNAL.M with the given input arguments.
%
%      OUTCOME_PER_SIGNAL('Property','Value',...) creates a new OUTCOME_PER_SIGNAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before outcome_per_signal_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to outcome_per_signal_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help outcome_per_signal

% Last Modified by GUIDE v2.5 24-Mar-2020 21:51:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @outcome_per_signal_OpeningFcn, ...
    'gui_OutputFcn',  @outcome_per_signal_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before outcome_per_signal is made visible.
function outcome_per_signal_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output_dir args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to outcome_per_signal (see VARARGIN)
dbstop if error
% Choose default command line output_dir for usv_analysis_ver2
handles.output_dir = hObject;

% Update handles structure
guidata(hObject, handles);
parentDir = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(parentDir));

% --- Outputs from this function are returned to the command line.
function varargout = outcome_per_signal_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output_dir args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output_dir from handles structure
varargout{1} = handles.output_dir;


% --- Executes on selection change in list_of_signals.
function list_of_signals_Callback(hObject, eventdata, handles)
% hObject    handle to list_of_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns list_of_signals contents as cell array
%        contents{get(hObject,'Value')} returns selected item from list_of_signals

% --- Executes during object creation, after setting all properties.
function list_of_signals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to list_of_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plot_pb.
function plot_pb_Callback(hObject, eventdata, handles)
% hObject    handle to plot_pb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% calculate spectogram
global param
global L
global prev_X
global prev_TH
global prev_IDX
global cmap_types
Fs =250000;
% Initialize the slider
set(handles.slider1,'Value',0);

% get the current signal

%
Idx=get(handles.list_of_signals,'Value');
% THE FIRST TIME FOR THIS SPECIFIC SIGNAL
%========================================
if isempty(prev_IDX) %|| ~strcmp(param.signal_path{Idx},param.signal_path{prev_IDX})
    prev_X =struct('X',[],'t',[],'f',[]); prev_TH =[];
    set(handles.time_data,'String','-');
    set(handles.freq_data,'String','-');
    set(handles.call_idx_data,'String','-');
    % add all the plot in demand
    if any(strcmpi('raster plot',param.plot_list))
        set(handles.raster_plot,'Visible','Off');
        set(handles.text_raster,'Visible','Off');
%         set(handles.raster_plot,'YLim',[0,1]);
    end
    
end
TH = get(handles.slider_threshold,'Value');

if isempty(param.signal)
    param.signal = cell(numel(param.signal_path),1);
end
if isempty(param.signal{Idx}) && isempty(prev_X.X)
    [param.signal{Idx}, Fs]=audioread(param.signal_path{Idx});
    
end
Xin =struct('t',[],'f',[],'X',[]);
added_info = struct('StEndMatF',[],'cmap_types',[],'catagory',[],'Time',[],'Formants',[],'dbdown',[]);
axes(handles.axes_spectogram);
%Xin = prev_X;
added_info.dbdown = TH;
if isempty(param.StEndMatF{Idx})||all(isnan(param.StEndMatF{Idx}(:)))
   [c_Xout,c_added_info ]= spectrogram_disp(param.signal{Idx},Fs,Xin,added_info, handles.axes_data, param, Idx);
   set(handles.calls_num,'String',num2str(size(param.StEndMatF{Idx},1)));
   set(handles.raster_plot,'YLim',[0,1]);
   %er=errordlg('No syllables found');
   return;
  
   elseif ~param.classification
    %X_ptr = libpointer('double');
    if get(handles.addFreqData,'Value')
        load(param.calls_feautre_mat{Idx})
        added_info.StEndMatF = param.StEndMatF{Idx};
        added_info.Time = time_formant;
        added_info.Formants = formants;
        
    else
        added_info.StEndMatF = param.StEndMatF{Idx};
        %[X_ptr,t,f] = calllib('myspectrogram','myspectrogram',param.signal{Idx},{2048,250000,hamming(512),256,1,TH,prev_X,param.StEndMatF{Idx}},[],[]);
      
    end
else
    if get(handles.addFreqData,'Value')
        load(param.calls_feautre_mat{Idx});
        added_info.StEndMatF = param.StEndMatF{Idx};
        added_info.Time = time_formant;
        added_info.Formants = formants;
        added_info.catagory = {param.model_feature(:, :).name};
        
    else
        added_info.StEndMatF = param.StEndMatF{Idx};
         added_info.catagory = {param.model_feature(:, :).name};

    end
end
[c_Xout,c_added_info ]= spectrogram_disp(param.signal{Idx},Fs,Xin,added_info, handles.axes_data, param, Idx);

L=size(c_Xout.X,2);
% in 10^3;
L= L*(10^(-3));
xlim(handles.axes_spectogram,[0,0.6]);

% NUMBER OF CALLS DETECTED
set(handles.calls_num,'String',num2str(size(param.StEndMatF{Idx},1)));
if size(param.StEndMatF{Idx},2)==2
    param.StEndMatF{Idx}=[param.StEndMatF{Idx},ones(size(param.StEndMatF{Idx},1),1)];
end
prev_TH =   TH;
prev_X.X  =   c_Xout.X;
prev_X.t  =   c_Xout.t;
prev_X.f  =   c_Xout.f;
prev_IDX =  Idx;
CAX = get(handles.axes_spectogram,'Children');
set(CAX,'ButtonDownFcn',{@ImageClickCallback,handles});
set(handles.raster_plot,'XLim',[prev_X.t(1),prev_X.t(end)]);
if isempty(cmap_types)
    
    if isempty(param.model_feature)
        NumColor = max(unique(param.StEndMatF{Idx}(:,3))) ;
    else
        NumColor = numel({param.model_feature(:, :).name});
    end
    
    C_spec = colormap(hsv(NumColor));
else
    C_spec = cmap_types;
end


hold off
hold all
if any(strcmpi('raster plot',param.plot_list)) && ~[isempty(param.StEndMatF{Idx})||all(isnan(param.StEndMatF{Idx}(:)))] ;
    AllType  = unique(param.StEndMatF{Idx}(:,3));
    NumOfTypes = zeros(size(AllType));
    for ii=1:length(AllType)
        % wrong classification according to gold standart
        spikes = mean(param.StEndMatF{Idx,1}([param.StEndMatF{Idx,1}(:,3)==AllType(ii)],1:2),2);
        NumOfTypes(ii) = length(spikes);
        if AllType(ii)==(-1) || AllType(ii)==(0)
            
            stem(handles.raster_plot,spikes,1.2*ones(1,length(spikes)),'Color','k');
            
        else
            
            stem(handles.raster_plot,spikes,1.2*ones(1,length(spikes)),'Color',C_spec(AllType(ii),:));
        end
        hold on
    end
    set(handles.raster_plot,'YLim',[0,1]);
    hold off
end


% create legend
%==============

set(handles.tag1,'BackgroundColor',[0,0,0],'ForegroundColor',[1,1,1],'FontSize',7);
if any(AllType==(-1))
    set(handles.tag1,'String',['Unrecognized',' (',num2str(NumOfTypes(AllType==(-1))),' )']);
else
    set(handles.tag1,'String','Unrecognized');
    
end

for cc=1:size(C_spec,1)
    
    set(eval(['handles.tag',[num2str(cc+1)]]),'BackgroundColor',C_spec(cc,:));
    if isempty(param.model_path)
        model_name = ['L_',num2str(cc)];
    else
        [~,model_name,~]=fileparts(param.model_path{cc});
    end
    if any(AllType==cc)
        
        set(eval(['handles.tag',[num2str(cc+1)]]),'String',[model_name,' (',num2str(NumOfTypes(AllType==cc)),' )']);
        
    else
        set(eval(['handles.tag',[num2str(cc+1)]]),'String',model_name);
    end
end

% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global L
IDX = get(hObject,'Value');
IDX = IDX*L;
% get length of data
%L=size(X,2);
%placment=round(L*IDX);
if IDX+0.6<=L
    
    xlim(handles.axes_spectogram,[IDX,0.6+IDX]);
else
    xlim(handles.axes_spectogram,[L-0.6,L]);
end
% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to slider_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
IDX = get(hObject,'Value');

set(handles.text_threshold,'String',['Threshold: ' ,num2str(IDX)]);

% --- Executes during object creation, after setting all properties.
function slider_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function ImageClickCallback ( objectHandle , eventData,handles )

global param
global CallNum
global axesHandle 

axesHandle  = get(objectHandle,'Parent');
if ishandle(axesHandle)
    Idx=get(handles.list_of_signals,'Value');
    coordinates = get(axesHandle,'CurrentPoint');
    coordinates = coordinates(1,1:2);
    Time = (coordinates(1));
    Freq = (coordinates(2));
%    [ StEndMatF{Idx} ] = Real_time( param, param.StEndMatF{Idx}, Idx, 0 );
    StEndMatF=param.StEndMatF; 
   CallNum = find([StEndMatF{Idx}(:,1)<=Time] & [StEndMatF{Idx}(:,2)>=Time]);
    % print it on a window for spectogram data
    set(handles.time_data,'String',num2str(Time));
    set(handles.freq_data,'String',num2str(Freq));
    if ~isempty(CallNum)
        set(handles.call_idx_data,'String',num2str(CallNum))
    else
        set(handles.call_idx_data,'String','-');
    end
    
else
    
    set(handles.time_data,'String','-');
    set(handles.freq_data,'String','-');
    set(handles.call_idx_data,'String','-');
       
end
%C={'Class'; 'Complex'; 'Harmonics'; 'Two-Syllable'; 'Upward'; 'Downward';...
 %  'Chevron'; 'Short'; 'Composite'; 'Frequency Steps'; 'Flat'; 'Other'};

% set(handles.Class_List,'Value',1);
% set(handles.Grade, 'String', 'Grade [%]');


% --- Executes on button press in addFreqData.
function addFreqData_Callback(hObject, eventdata, handles)
% hObject    handle to addFreqData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of addFreqData


% --------------------------------------------------------------------
function exit_Callback(hObject, eventdata, handles)
% hObject    handle to exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if libisloaded('myspectrogram')
    unloadlibrary('myspectrogram');
end
return

% --- Executes on selection change in Class_List.
function Class_List_Callback(hObject, eventdata, handles)
% hObject    handle to Class_List (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Class_List contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Class_List


% --- Executes during object creation, after setting all properties.
function Class_List_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Class_List (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in Save_Class_button.
function Save_Class_button_Callback(hObject, eventdata, handles)
% hObject    handle to Save_Class_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global param
global CallNum
global choice;

global manual_StartEnd
global axesHandle

Idx=get(handles.list_of_signals,'Value');

if choice == 2
% date
% date=param.date{Idx};
% date=[num2str(date(2)),'.', num2str(date(1)),'.', num2str(date(3))];

% name of pup and recording number
[pathstr, rec_num,~] =fileparts(param.signal_path{Idx});
I_name = strfind(pathstr,'day');
name=pathstr(I_name-10:I_name-2);
mom = pathstr(I_name-20:I_name-12);
%I_endname=strfind(name, '\');
%session=name(I_endname(1)+1:I_endname(2)-1);
session = 'session1';
%name=name(1:I_endname(1)-1);

%start and end point
if isempty(CallNum)   
    StartT = manual_StartEnd(1);
    EndT = manual_StartEnd(2);
else
%     [ StEndMatF{Idx} ] = Real_time( param, param.StEndMatF{Idx}, Idx, 0 );
    StEndMatF{Idx} = param.StEndMatF{Idx};
    StartT=StEndMatF{Idx}(CallNum,1);
    EndT=StEndMatF{Idx}(CallNum,2);    
end

% 
% 
% [ StEndMatF{Idx} ] = Real_time( param, param.StEndMatF{Idx}, Idx, 0 );
% StartT=StEndMatF{Idx}(CallNum,1);
% EndT=StEndMatF{Idx}(CallNum,2);

%class
contents = cellstr(get(handles.Class_List,'String'));
class=contents{get(handles.Class_List,'Value')};

path = param.results_folder;
grade=get(handles.Grade,'String');
d=datestr(now,'dd/mm/yy');
% d=[d(1:2), d(4:6), d(10:11)];
out = get(handles.uipanel9.Children(3),'String');
xlsappend(strcat(out,'\gold standard-pups.xlsx'),...
    {path, mom, name, rec_num, num2str(StartT),num2str(EndT), class, grade, d});
set(handles.Grade,'String','');
set(handles.Class_List,'Value',1);
warndlg('saved in excel','success');
else
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% date
date=param.date{Idx};
date=[num2str(date(2)),'.', num2str(date(3)),'.', num2str(date(1))]; %% date

% name of pup and recording number
[pathstr, rec_num,~] =fileparts(param.signal_path{Idx});
%%%%%
 I_name = strfind(pathstr,'Batch');
I_ch = strfind(pathstr,'\ch');
name=pathstr(I_name:I_ch-1);
I_endname=strfind(name, '\');
nameA=name(I_endname(1)+1:end);  %%% name
session = name(1:I_endname(1)-1); %% session
%%%%%%%%%%%%%%%%%%%%%%%%%
%start and end point
if isempty(CallNum)   
    StartT = manual_StartEnd(1);
    EndT = manual_StartEnd(2);
else
%     [ StEndMatF{Idx} ] = Real_time( param, param.StEndMatF{Idx}, Idx, 0 );
    StartT=StEndMatF{Idx}(CallNum,1);
    EndT=StEndMatF{Idx}(CallNum,2);    
end

% [ StEndMatF{Idx} ] = Real_time( param, param.StEndMatF{Idx}, Idx, 0 );
% StartT=StEndMatF{Idx}(CallNum,1);
% EndT=StEndMatF{Idx}(CallNum,2);

%class
contents = cellstr(get(handles.Class_List,'String'));
class=contents{get(handles.Class_List,'Value')};

grade=get(handles.Grade,'String');
d=datestr(now);
d=[d(1:2), d(4:6), d(10:11)];    
xlsappend('E:\renana\gold standard-Adults renana.xlsx',{date, nameA, session, rec_num, num2str(StartT),num2str(EndT), class, grade, d});
end    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function excel_line_num_Callback(hObject, eventdata, handles)
% hObject    handle to excel_line_num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of excel_line_num as text
%        str2double(get(hObject,'String')) returns contents of excel_line_num as a double


% --- Executes during object creation, after setting all properties.
function excel_line_num_CreateFcn(hObject, eventdata, handles)
% hObject    handle to excel_line_num (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Grade_Callback(hObject, eventdata, handles)
% hObject    handle to Grade (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Grade as text
%        str2double(get(hObject,'String')) returns contents of Grade as a double


% --- Executes during object creation, after setting all properties.
function Grade_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Grade (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_syl.
function save_syl_Callback(hObject, eventdata, handles)
% hObject    handle to save_syl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global manual_StartEnd
global axesHandle
global Harmony
coordinates = get(axesHandle,'CurrentPoint');
time=coordinates(1);
manual_StartEnd=[manual_StartEnd; time];
Harmony=[Harmony, get(handles.Harmony_check, 'Value')];

% --- Executes on button press in End_manual.
function End_manual_Callback(hObject, eventdata, handles)
% hObject    handle to End_manual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global manual_StartEnd
global param
global Harmony
global choice;

manual_StartEnd = unique(manual_StartEnd);
temp = diff(manual_StartEnd);
temp = temp(1:2:end)>2.5;

if isempty(manual_StartEnd) || ~(mod(length(manual_StartEnd),2)== 0) || any(temp)
     warndlg('Push the clr button and sart over','Error in manual segmentation')
else
%     if ~isempty(manual_StartEnd) 
        Start=manual_StartEnd(1:2:length(manual_StartEnd));
        End=manual_StartEnd(2:2:length(manual_StartEnd));
        %date
        Idx=get(handles.list_of_signals,'Value');
        date=param.date{Idx};
        date=[num2str(date(2)),'.', num2str(date(1)),'.', num2str(date(3))];
        [pathstr, rec_num,~] =fileparts(param.signal_path{Idx});
        %current date
        d=datestr(now,'dd/mm/yy');
        path = param.results_folder;
        contents = cellstr(get(handles.Class_List,'String'));
        class=contents{get(handles.Class_List,'Value')};
        grade=get(handles.Grade,'String');
        
%         d=[d(1:2), d(4:6), d(10:11)];
        if choice == 2
            % name of pup and recording number
            I_name = strfind(pathstr,'day');
            name=pathstr(I_name-10:I_name-2);
            mom = pathstr(I_name-20:I_name-12);
            %I_endname=strfind(name, '\');
            %session=name(I_endname(1)+1:I_endname(2)-1);
            session = 'session1';
            %name=name(1:I_endname(1)-1);
            out = get(handles.uipanel9.Children(3),'String');
            for syl=1:length(Start)
                xlsappend(strcat(out,'\Manual segmentation - pups.xlsx'),...
                    {path, mom, name, rec_num, num2str(Start(syl)),...
                    num2str(End(syl)),class, grade, num2str(Harmony(2*syl-1)), d});
            end
        else
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%
        I_name = strfind(pathstr,'Batch');
        I_ch = strfind(pathstr,'\ch');
        name=pathstr(I_name:I_ch-1);
        I_endname=strfind(name, '\');
        nameA=name(I_endname(1)+1:end);  %%% name
        session = name(1:I_endname(1)-1); %% session
        for syl=1:length(Start)
          xlswrite('E:\Recordings\matlab codes\12_xls_tables\Manual segmentation-Adults.xlsx',{date, nameA, session, rec_num, num2str(Start(syl)),num2str(End(syl)), num2str(Harmony(2*syl-1)), d});    
%          xlsappend('C:\Users\Shachar\Documents\MATLAB\codes\12_xls_tables\OLD.xlsx',{date, nameA, session, rec_num, num2str(start(syl)),num2str(End(syl)), num2str(Harmony(2*syl-1)), d});        
        end
        end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    manual_StartEnd=[];
    Harmony=[];
    warndlg('saved in excel','success');

%     end
end

% --- Executes on button press in Harmony_check.
function Harmony_check_Callback(hObject, eventdata, handles)
% hObject    handle to Harmony_check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Harmony_check


% --- Executes on button press in clr.
function clr_Callback(hObject, eventdata, handles)
% hObject    handle to clr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global manual_StartEnd
global Harmony
global choice;

manual_StartEnd=[];
Harmony=[];


% --- Executes during object creation, after setting all properties.
function axes_spectogram_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_spectogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_spectogram


% --- Executes on button press in browse.
function browse_Callback(hObject, eventdata, handles)
% hObject    handle to browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
filename = uipickfiles('type',{'*.wav','Signal recordings'});
filename = filename(:);

global param
set(handles.signal_list,'String',char(filename));

% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on selection change in signal_list.
function signal_list_Callback(hObject, eventdata, handles)
% hObject    handle to signal_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns signal_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from signal_list


% --- Executes during object creation, after setting all properties.
function signal_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to signal_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on key press with focus on radiobutton2 and none of its controls.
function radiobutton2_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% I. check form - and values
%----------------------------
global param
param = parameters_usv;
[err_flag,errdlg]= check_form(handles);
if err_flag
    warndlg(errdlg);
    return
end
% II. fill the param class according to the form
%------------------------------------------------
% in check_form function

% III. send to skeleton_usv
%--------------------------
%set(handles.start,'Enable','off');
set(handles.error_display,'String','Please wait while running...');
[p,err_flag] = skeleton_usv(param);
if err_flag == 0
    % No error
    set(handles.start,'Enable','on');
else
    set(handles.error_display,'String','Un error Occurred during function run, please start over');
end
param = p;
global Manual_class
Manual_class=struct('Start_Point', {}, 'End_Point', {}, 'Class', {}); 

global choice;

global Manual_StartEnd
Manual_StartEnd=[];

global Harmony
Harmony=[];

% Choose default command line output_dir for outcome_per_signal
% param = varargin{1};
param.signal_path =param.signal_path(:);
signal_names = char(param.signal_path);
if length(param.trial)>1
    trial_number  = num2str(param.trial(:));
    signal_names = [signal_names , trial_number];
end
% changing the list names
j = 1;
for i=1:size(param.StEndMatF,1)
    if size(param.StEndMatF{i},1)>0
        signals(j) = param.signal_path(i);
        StEndMatFNew{j} = param.StEndMatF{i};
        a(j) = i;
        j = j + 1;
    end
end
set(handles.list_of_signals,'String',char(signals'));
param.StEndMatF = StEndMatFNew';
param.signal = param.signal(a);
% set(handles.list_of_signals,'String',signal_names);
handles.output_dir = hObject;

guidata(hObject, handles);


function [err_flag,errdlg] = check_form(handles)
err_flag = 1;
errdlg = '';

global param
param = parameters_usv;
param.signal_path = get(handles.signal_list,'String');
% II. OUTPUT_FOLDER
if strcmp(get(handles.signal_list,'String'),'signals file list')
    errdlg = 'No file was chosen..';
    param.results_folder = strtrim(param.signal_path(1,1:end-13));
    return
else
       param.results_folder = strtrim(param.signal_path(1,1:end-13));
       err_flag = 0;
end


% III. SEGMENTATION

% NOT EMPTY
param.segmantation = true;
param.signal_path = cellstr(get(handles.signal_list,'String'));
param.preprocessing =  1;
param.save_signal = 0;
for ii =1:numel(param.signal_path)
    [param.channel{ii},param.date{ii}]=get_info_from_file_path(param.signal_path{ii}) ;
end

param.plot_flag = 1;


% --- Executes on button press in browse_output.
function browse_output_Callback(hObject, eventdata, handles)
% hObject    handle to browse_output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pathname = uigetdir;
set(handles.uipanel9.Children(3),'String',pathname);


function output_dir_Callback(hObject, eventdata, handles)
% hObject    handle to output_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of output_dir as text
%        str2double(get(hObject,'String')) returns contents of output_dir as a double


% --- Executes during object creation, after setting all properties.
function output_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to output_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
